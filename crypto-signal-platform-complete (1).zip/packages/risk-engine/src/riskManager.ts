import { StrategySignal } from '@crypto-signal/strategies';
import { AccountState, PositionSizeResult } from './types.js';

export class RiskManager {
  private defaultRiskPercent = 0.01; // 1% risk rule
  private estimatedFeeRate = 0.0005; // 0.05% maker/taker fee approximation
  private minRiskReward = 2.0;

  public evaluateTradeRisk(account: AccountState, signal: StrategySignal): PositionSizeResult {
    // 1. Portfolio & Account Risk Checks
    if (account.openPositionsCount >= account.maxOpenTrades) {
      return this.reject(account, signal, 'Maximum open trades limit reached.');
    }
    if (account.dailyLossUsd >= account.maxDailyLossUsd) {
      return this.reject(account, signal, 'Maximum daily loss limit reached.');
    }
    if (signal.riskRewardRatio < this.minRiskReward) {
      return this.reject(account, signal, `Risk/Reward ratio ${signal.riskRewardRatio.toFixed(2)} is below minimum 1:2 requirement.`);
    }

    // 2. Account Equity & 1% Risk Calculation
    const accountEquity = account.balance;
    const riskAmountUsd = accountEquity * this.defaultRiskPercent; // Exactly 1% of equity

    const entryPrice = signal.suggestedEntryPrice;
    const stopLossPrice = signal.stopLossPrice;
    const stopLossDistance = Math.abs(entryPrice - stopLossPrice);

    if (stopLossDistance <= 0) {
      return this.reject(account, signal, 'Invalid stop-loss distance (zero or negative).');
    }

    const stopLossDistancePercent = (stopLossDistance / entryPrice) * 100;

    // 3. Position Sizing Formula: Quantity = (Equity * Risk%) / (Entry Price - Stop Loss Price)
    const contractQuantity = riskAmountUsd / stopLossDistance;
    const positionSizeUsd = contractQuantity * entryPrice;

    // Estimate trading fees
    const estimatedFeeUsd = positionSizeUsd * this.estimatedFeeRate * 2; // Entry + Exit

    // Support small accounts (e.g., $10 balance) subject to precision constraints
    if (positionSizeUsd <= 0 || contractQuantity <= 0) {
      return this.reject(account, signal, 'Calculated position size is too small for execution.');
    }

    // Calculate TP3 (Trailing runner target default at 5R)
    const riskPerUnit = stopLossDistance;
    const tp3Price =
      signal.direction === 'BUY'
        ? entryPrice + riskPerUnit * 5.0
        : entryPrice - riskPerUnit * 5.0;

    return {
      approved: true,
      accountEquity,
      riskAmountUsd,
      entryPrice,
      stopLossPrice,
      stopLossDistancePercent,
      contractQuantity,
      positionSizeUsd,
      estimatedFeeUsd,
      riskRewardRatio: signal.riskRewardRatio,
      tp1Price: signal.tp1Price,
      tp2Price: signal.tp2Price,
      tp3Price
    };
  }

  private reject(account: AccountState, signal: StrategySignal, reason: string): PositionSizeResult {
    return {
      approved: false,
      rejectReason: reason,
      accountEquity: account.balance,
      riskAmountUsd: account.balance * this.defaultRiskPercent,
      entryPrice: signal.suggestedEntryPrice,
      stopLossPrice: signal.stopLossPrice,
      stopLossDistancePercent: 0,
      contractQuantity: 0,
      positionSizeUsd: 0,
      estimatedFeeUsd: 0,
      riskRewardRatio: signal.riskRewardRatio,
      tp1Price: signal.tp1Price,
      tp2Price: signal.tp2Price,
      tp3Price: 0
    };
  }
}
