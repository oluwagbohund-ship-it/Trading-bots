import { StrategySignal } from '@crypto-signal/strategies';

export interface AccountState {
  accountId: string;
  balance: number;         // Simulated account equity (e.g. $1,000)
  riskPercentage: number;  // Fixed at 1.0 (1%)
  openPositionsCount: number;
  maxOpenTrades: number;
  dailyLossUsd: number;
  maxDailyLossUsd: number;
}

export interface PositionSizeResult {
  approved: boolean;
  rejectReason?: string;
  accountEquity: number;
  riskAmountUsd: number;
  entryPrice: number;
  stopLossPrice: number;
  stopLossDistancePercent: number;
  contractQuantity: number;
  positionSizeUsd: number;
  estimatedFeeUsd: number;
  riskRewardRatio: number;
  tp1Price: number;
  tp2Price: number;
  tp3Price: number;
}
