import {
  calculateATR,
  identifySwingPoints,
  TrendlineEngine,
  projectTrendlinesToTimestamp,
  SupplyDemandEngine
} from '@crypto-signal/indicators';
import {
  TradingStrategy,
  MultiTimeframeSnapshot,
  StrategySignal,
  TrendlineEntryMode
} from '../types.js';
import { evaluateTopDownBias } from './biasEngine.js';

export interface TopDownStrategyConfig {
  enabledModes: TrendlineEntryMode[];
  minRiskReward: number;      // Default 2.0 (1:2 R:R minimum)
  tp1RMultiple: number;       // Default 1.5R
  tp2RMultiple: number;       // Default 3.0R
  atrStopMultiplier: number;  // Buffer beyond swing/trendline
  minQualityScore: number;    // Default 65/100
}

const DEFAULT_CONFIG: TopDownStrategyConfig = {
  enabledModes: ['BREAK', 'BOUNCE', 'RETEST'],
  minRiskReward: 2.0,
  tp1RMultiple: 1.5,
  tp2RMultiple: 3.0,
  atrStopMultiplier: 1.0,
  minQualityScore: 65
};

export class TopDownTrendlineStrategy implements TradingStrategy {
  public readonly id = 'TOP_DOWN_TRENDLINE' as const;
  public readonly name = 'Top-Down Trendline Strategy';

  private config: TopDownStrategyConfig;
  private trendlineEngine: TrendlineEngine;
  private sdEngine: SupplyDemandEngine;

  constructor(config?: Partial<TopDownStrategyConfig>) {
    this.config = { ...DEFAULT_CONFIG, ...config };
    this.trendlineEngine = new TrendlineEngine();
    this.sdEngine = new SupplyDemandEngine();
  }

  public evaluate(snapshot: MultiTimeframeSnapshot): StrategySignal | null {
    const candles5m = (snapshot.candles['5m'] || []).filter((c) => c.isClosed);
    const candles1h = (snapshot.candles['1h'] || []).filter((c) => c.isClosed);
    const candles4h = (snapshot.candles['4h'] || []).filter((c) => c.isClosed);

    if (candles5m.length < 30 || candles4h.length < 20) return null;

    // 1. Evaluate Higher-Timeframe Ladder (1M -> 1W -> 1D -> 4H)
    const biasReport = evaluateTopDownBias(snapshot.candles);
    if (biasReport.overallBias === 'NEUTRAL') return null;

    const last5m = candles5m[candles5m.length - 1];
    const prev5m = candles5m[candles5m.length - 2];
    const atr5m = calculateATR(candles5m, 14);
    const currentAtr5m = atr5m[atr5m.length - 1];
    if (!currentAtr5m || currentAtr5m <= 0) return null;

    // 2. Detect 4H Main Trendlines & 1H Setup Refinement Trendlines
    const swings4h = identifySwingPoints(candles4h, 4, 4);
    const lines4h = this.trendlineEngine.detectTrendlines(candles4h, swings4h.swingHighs, swings4h.swingLows, '4h');

    const swings1h = identifySwingPoints(candles1h, 3, 3);
    const lines1h = this.trendlineEngine.detectTrendlines(candles1h, swings1h.swingHighs, swings1h.swingLows, '1h');

    const projected4h = projectTrendlinesToTimestamp(this.trendlineEngine, lines4h, last5m.openTime, last5m.close);
    const projected1h = projectTrendlinesToTimestamp(this.trendlineEngine, lines1h, last5m.openTime, last5m.close);
    const allProjected = [...projected4h, ...projected1h];

    if (allProjected.length === 0) return null;

    // 3. Detect Supply & Demand Zones on 4H for confluence
    const atr4h = calculateATR(candles4h, 14);
    const zones4h = this.sdEngine.detectZones(candles4h, atr4h, '4h');

    // 4. Evaluate 5M Entry Confirmation across BOUNCE, BREAK, and RETEST modes
    for (const proj of allProjected) {
      const linePrice = proj.currentProjectedPrice;
      const lineDir = proj.sourceTrendline.direction;

      // Mode A: BOUNCE (Trendline holds with higher-timeframe bias alignment)
      if (this.config.enabledModes.includes('BOUNCE') && !proj.sourceTrendline.isBroken) {
        if (biasReport.overallBias === 'BULLISH' && lineDir === 'ASCENDING') {
          const testedLine = last5m.low <= linePrice + currentAtr5m * 0.5 && last5m.close > linePrice;
          const bullishClose = last5m.close > last5m.open && last5m.close > prev5m.high;
          if (testedLine && bullishClose) {
            return this.buildSignal(snapshot, 'BUY', 'BOUNCE', last5m, linePrice, currentAtr5m, biasReport.overallBias, [proj.sourceTrendline], zones4h);
          }
        }
        if (biasReport.overallBias === 'BEARISH' && lineDir === 'DESCENDING') {
          const testedLine = last5m.high >= linePrice - currentAtr5m * 0.5 && last5m.close < linePrice;
          const bearishClose = last5m.close < last5m.open && last5m.close < prev5m.low;
          if (testedLine && bearishClose) {
            return this.buildSignal(snapshot, 'SELL', 'BOUNCE', last5m, linePrice, currentAtr5m, biasReport.overallBias, [proj.sourceTrendline], zones4h);
          }
        }
      }

      // Mode B: BREAK (Counter-trendline breaks in the direction of higher-timeframe bias)
      if (this.config.enabledModes.includes('BREAK') && proj.sourceTrendline.isBroken) {
        if (biasReport.overallBias === 'BULLISH' && lineDir === 'DESCENDING') {
          const justBrokeUp = prev5m.close <= linePrice && last5m.close > linePrice + currentAtr5m * 0.25;
          if (justBrokeUp) {
            return this.buildSignal(snapshot, 'BUY', 'BREAK', last5m, linePrice, currentAtr5m, biasReport.overallBias, [proj.sourceTrendline], zones4h);
          }
        }
        if (biasReport.overallBias === 'BEARISH' && lineDir === 'ASCENDING') {
          const justBrokeDown = prev5m.close >= linePrice && last5m.close < linePrice - currentAtr5m * 0.25;
          if (justBrokeDown) {
            return this.buildSignal(snapshot, 'SELL', 'BREAK', last5m, linePrice, currentAtr5m, biasReport.overallBias, [proj.sourceTrendline], zones4h);
          }
        }
      }

      // Mode C: RETEST (Broken trendline retested from the opposite side)
      if (this.config.enabledModes.includes('RETEST') && proj.sourceTrendline.isBroken) {
        if (biasReport.overallBias === 'BULLISH' && lineDir === 'DESCENDING') {
          const retestedFromAbove = prev5m.close > linePrice && last5m.low <= linePrice + currentAtr5m * 0.3 && last5m.close > linePrice && last5m.close > last5m.open;
          if (retestedFromAbove) {
            return this.buildSignal(snapshot, 'BUY', 'RETEST', last5m, linePrice, currentAtr5m, biasReport.overallBias, [proj.sourceTrendline], zones4h);
          }
        }
        if (biasReport.overallBias === 'BEARISH' && lineDir === 'ASCENDING') {
          const retestedFromBelow = prev5m.close < linePrice && last5m.high >= linePrice - currentAtr5m * 0.3 && last5m.close < linePrice && last5m.close < last5m.open;
          if (retestedFromBelow) {
            return this.buildSignal(snapshot, 'SELL', 'RETEST', last5m, linePrice, currentAtr5m, biasReport.overallBias, [proj.sourceTrendline], zones4h);
          }
        }
      }
    }

    return null;
  }

  private buildSignal(
    snapshot: MultiTimeframeSnapshot,
    direction: 'BUY' | 'SELL',
    entryMode: TrendlineEntryMode,
    signalCandle: { openTime: number; close: number; low: number; high: number },
    linePrice: number,
    atr5m: number,
    bias: 'BULLISH' | 'BEARISH',
    trendlines: any[],
    zones: any[]
  ): StrategySignal | null {
    // Entry occurs at next available 5M candle open (approximated by closed candle close at trigger boundary; executed on next open)
    const entryPrice = signalCandle.close;
    const stopLossPrice =
      direction === 'BUY'
        ? Math.min(signalCandle.low, linePrice) - atr5m * this.config.atrStopMultiplier
        : Math.max(signalCandle.high, linePrice) + atr5m * this.config.atrStopMultiplier;

    const riskPerUnit = Math.abs(entryPrice - stopLossPrice);
    if (riskPerUnit <= 0) return null;

    const tp1Price =
      direction === 'BUY'
        ? entryPrice + riskPerUnit * this.config.tp1RMultiple
        : entryPrice - riskPerUnit * this.config.tp1RMultiple;

    const tp2Price =
      direction === 'BUY'
        ? entryPrice + riskPerUnit * this.config.tp2RMultiple
        : entryPrice - riskPerUnit * this.config.tp2RMultiple;

    const riskRewardRatio = this.config.tp2RMultiple;
    if (riskRewardRatio < this.config.minRiskReward) return null;

    // Transparent 0-100 Signal Quality Score
    const breakdown: Record<string, number> = {
      higherTimeframeAlignment: 30,
      trendlineValidity: Math.min(25, trendlines[0].touchCount * 7),
      entryConfirmation: entryMode === 'RETEST' ? 20 : 15,
      supplyDemandConfluence: zones.length > 0 ? 15 : 5,
      riskRewardProfile: riskRewardRatio >= 3.0 ? 10 : 7
    };
    const qualityScore = Object.values(breakdown).reduce((a, b) => a + b, 0);

    if (qualityScore < this.config.minQualityScore) return null;

    return {
      strategyId: this.id,
      symbol: snapshot.symbol,
      direction,
      entryMode,
      executionTimeframe: '5m',
      higherTimeframeBias: bias,
      signalCandleTime: signalCandle.openTime,
      suggestedEntryPrice: entryPrice,
      stopLossPrice,
      tp1Price,
      tp2Price,
      riskRewardRatio,
      qualityScore,
      qualityBreakdown: breakdown,
      relevantTrendlines: trendlines.slice(0, 4),
      relevantZones: zones.slice(0, 2),
      rationale: `${bias} HTF ladder alignment with ${entryMode} confirmation on ${trendlines[0].timeframe.toUpperCase()} ${trendlines[0].direction} trendline.`
    };
  }
}
