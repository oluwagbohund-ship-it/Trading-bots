import { Candle, Timeframe } from '@crypto-signal/market-data';
import { identifySwingPoints } from '@crypto-signal/indicators';
import { MarketBias } from '../types.js';

export interface LadderBiasReport {
  monthly: MarketBias;
  weekly: MarketBias;
  daily: MarketBias;
  fourHour: MarketBias;
  overallBias: MarketBias;
}

/**
 * Evaluates higher-timeframe directional bias across 1M -> 1W -> 1D -> 4H
 * strictly from closed candles available at decision time.
 */
export function evaluateTopDownBias(candlesByTf: Record<Timeframe, Candle[]>): LadderBiasReport {
  const monthly = classifyTimeframeStructure(candlesByTf['1M'] || [], 2, 2);
  const weekly = classifyTimeframeStructure(candlesByTf['1w'] || [], 3, 3);
  const daily = classifyTimeframeStructure(candlesByTf['1d'] || [], 3, 3);
  const fourHour = classifyTimeframeStructure(candlesByTf['4h'] || [], 4, 4);

  const weights: Record<MarketBias, number> = { BULLISH: 0, BEARISH: 0, NEUTRAL: 0 };
  weights[monthly] += 1;
  weights[weekly] += 2;
  weights[daily] += 3;
  weights[fourHour] += 3;

  let overallBias: MarketBias = 'NEUTRAL';
  if (weights.BULLISH >= 6 && weights.BEARISH <= 2) {
    overallBias = 'BULLISH';
  } else if (weights.BEARISH >= 6 && weights.BULLISH <= 2) {
    overallBias = 'BEARISH';
  }

  return { monthly, weekly, daily, fourHour, overallBias };
}

function classifyTimeframeStructure(candles: Candle[], leftBars: number, rightBars: number): MarketBias {
  const closed = candles.filter((c) => c.isClosed);
  if (closed.length < leftBars + rightBars + 4) return 'NEUTRAL';

  const { swingHighs, swingLows } = identifySwingPoints(closed, leftBars, rightBars);
  if (swingHighs.length < 2 || swingLows.length < 2) return 'NEUTRAL';

  const lastHigh = swingHighs[swingHighs.length - 1].price;
  const prevHigh = swingHighs[swingHighs.length - 2].price;
  const lastLow = swingLows[swingLows.length - 1].price;
  const prevLow = swingLows[swingLows.length - 2].price;

  if (lastHigh > prevHigh && lastLow > prevLow) return 'BULLISH';
  if (lastHigh < prevHigh && lastLow < prevLow) return 'BEARISH';
  return 'NEUTRAL';
}
