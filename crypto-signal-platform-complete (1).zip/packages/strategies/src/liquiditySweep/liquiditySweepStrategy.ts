import { calculateATR, identifySwingPoints } from '@crypto-signal/indicators';
import { TradingStrategy, MultiTimeframeSnapshot, StrategySignal } from '../types.js';

export interface LiquiditySweepConfig {
  minRiskReward: number;
  atrStopBuffer: number;
}

const DEFAULT_CONFIG: LiquiditySweepConfig = {
  minRiskReward: 2.0,
  atrStopBuffer: 1.2
};

/**
 * STRATEGY 3: LIQUIDITY SWEEP REVERSAL
 * Detects price spikes beyond established swing highs/lows (stopping hunts / liquidity grabs)
 * followed by a confirmed close back inside the level.
 */
export class LiquiditySweepStrategy implements TradingStrategy {
  public readonly id = 'LIQUIDITY_SWEEP_REVERSAL' as const;
  public readonly name = 'Liquidity Sweep Reversal Strategy';
  private config: LiquiditySweepConfig;

  constructor(config?: Partial<LiquiditySweepConfig>) {
    this.config = { ...DEFAULT_CONFIG, ...config };
  }

  public evaluate(snapshot: MultiTimeframeSnapshot): StrategySignal | null {
    const candles5m = (snapshot.candles['5m'] || []).filter((c) => c.isClosed);
    const candles1h = (snapshot.candles['1h'] || []).filter((c) => c.isClosed);
    if (candles5m.length < 30 || candles1h.length < 20) return null;

    const last5m = candles5m[candles5m.length - 1];
    const atr = calculateATR(candles5m, 14);
    const currentAtr = atr[atr.length - 1];
    if (!currentAtr || currentAtr <= 0) return null;

    const { swingHighs, swingLows } = identifySwingPoints(candles1h, 3, 3);
    if (swingHighs.length === 0 || swingLows.length === 0) return null;

    const recentHigh = swingHighs[swingHighs.length - 1].price;
    const recentLow = swingLows[swingLows.length - 1].price;

    // Bearish Sweep Reversal (Bullish liquidity grabbed above recent high, then closed back below)
    if (last5m.high > recentHigh && last5m.close < recentHigh) {
      const entryPrice = last5m.close;
      const stopLossPrice = last5m.high + currentAtr * this.config.atrStopBuffer;
      const risk = stopLossPrice - entryPrice;
      if (risk <= 0) return null;

      const tp1Price = entryPrice - risk * 1.5;
      const tp2Price = entryPrice - risk * 3.0;

      return {
        strategyId: this.id,
        symbol: snapshot.symbol,
        direction: 'SELL',
        executionTimeframe: '5m',
        higherTimeframeBias: 'BEARISH',
        signalCandleTime: last5m.openTime,
        suggestedEntryPrice: entryPrice,
        stopLossPrice,
        tp1Price,
        tp2Price,
        riskRewardRatio: 3.0,
        qualityScore: 75,
        qualityBreakdown: { sweepDepth: 30, rejectionCandle: 25, riskReward: 20 },
        relevantTrendlines: [],
        relevantZones: [],
        rationale: `Liquidity sweep above 1H swing high (${recentHigh.toFixed(2)}) with immediate reversal close.`
      };
    }

    // Bullish Sweep Reversal (Bearish liquidity grabbed below recent low, then closed back above)
    if (last5m.low < recentLow && last5m.close > recentLow) {
      const entryPrice = last5m.close;
      const stopLossPrice = last5m.low - currentAtr * this.config.atrStopBuffer;
      const risk = entryPrice - stopLossPrice;
      if (risk <= 0) return null;

      const tp1Price = entryPrice + risk * 1.5;
      const tp2Price = entryPrice + risk * 3.0;

      return {
        strategyId: this.id,
        symbol: snapshot.symbol,
        direction: 'BUY',
        executionTimeframe: '5m',
        higherTimeframeBias: 'BULLISH',
        signalCandleTime: last5m.openTime,
        suggestedEntryPrice: entryPrice,
        stopLossPrice,
        tp1Price,
        tp2Price,
        riskRewardRatio: 3.0,
        qualityScore: 75,
        qualityBreakdown: { sweepDepth: 30, rejectionCandle: 25, riskReward: 20 },
        relevantTrendlines: [],
        relevantZones: [],
        rationale: `Liquidity sweep below 1H swing low (${recentLow.toFixed(2)}) with immediate reversal close.`
      };
    }

    return null;
  }
}
