import { calculateATR } from '@crypto-signal/indicators';
import { TradingStrategy, MultiTimeframeSnapshot, StrategySignal } from '../types.js';

export interface OrderBlockConfig {
  minDisplacementAtr: number;
  minRiskReward: number;
}

const DEFAULT_CONFIG: OrderBlockConfig = {
  minDisplacementAtr: 1.8,
  minRiskReward: 2.0
};

/**
 * STRATEGY 4: ORDER BLOCK RETEST
 * Identifies impulse displacement candles and the preceding opposing candle (Order Block),
 * waiting for a retest of the zone for entry.
 */
export class OrderBlockStrategy implements TradingStrategy {
  public readonly id = 'ORDER_BLOCK_RETEST' as const;
  public readonly name = 'Order Block Retest Strategy';
  private config: OrderBlockConfig;

  constructor(config?: Partial<OrderBlockConfig>) {
    this.config = { ...DEFAULT_CONFIG, ...config };
  }

  public evaluate(snapshot: MultiTimeframeSnapshot): StrategySignal | null {
    const candles1h = (snapshot.candles['1h'] || []).filter((c) => c.isClosed);
    const candles5m = (snapshot.candles['5m'] || []).filter((c) => c.isClosed);
    if (candles1h.length < 20 || candles5m.length < 30) return null;

    const atr1h = calculateATR(candles1h, 14);
    const last5m = candles5m[candles5m.length - 1];
    const currentAtr5m = calculateATR(candles5m, 14).slice(-1)[0];

    // Scan recent 1H candles for bullish order block (bearish candle before strong bullish impulse)
    for (let i = 1; i < candles1h.length - 1; i++) {
      const prev = candles1h[i - 1]; // Opposing candle
      const curr = candles1h[i];     // Displacement
      const atr = atr1h[i];

      if (!atr || atr <= 0) continue;

      const body = curr.close - curr.open;
      if (body >= atr * this.config.minDisplacementAtr && prev.close < prev.open) {
        // Bullish OB zone defined by prev candle high/low
        const obHigh = prev.high;
        const obLow = prev.low;

        // Check if current 5M price is retesting the 1H order block zone
        const retesting = last5m.low <= obHigh && last5m.high >= obLow && last5m.close > last5m.open;
        if (retesting) {
          const entryPrice = last5m.close;
          const stopLossPrice = obLow - currentAtr5m * 0.5;
          const risk = entryPrice - stopLossPrice;
          if (risk <= 0) continue;

          return {
            strategyId: this.id,
            symbol: snapshot.symbol,
            direction: 'BUY',
            executionTimeframe: '5m',
            higherTimeframeBias: 'BULLISH',
            signalCandleTime: last5m.openTime,
            suggestedEntryPrice: entryPrice,
            stopLossPrice,
            tp1Price: entryPrice + risk * 1.5,
            tp2Price: entryPrice + risk * 3.0,
            riskRewardRatio: 3.0,
            qualityScore: 70,
            qualityBreakdown: { displacementStrength: 30, obConfluence: 25, riskReward: 15 },
            relevantTrendlines: [],
            relevantZones: [],
            rationale: `Retest of 1H bullish Order Block zone [${obLow.toFixed(2)} - ${obHigh.toFixed(2)}].`
          };
        }
      }
    }

    return null;
  }
}
