import { calculateATR, identifySwingPoints } from '@crypto-signal/indicators';
import { TradingStrategy, MultiTimeframeSnapshot, StrategySignal } from '../types.js';

export interface BreakAndRetestConfig {
  minRiskReward: number;
  atrStopBuffer: number;
  minQualityScore: number;
}

const DEFAULT_CONFIG: BreakAndRetestConfig = {
  minRiskReward: 2.0,
  atrStopBuffer: 1.0,
  minQualityScore: 60
};

/**
 * STRATEGY 2: BREAK AND RETEST
 * Identifies established horizontal price levels from swing extrema,
 * requires a confirmed breakout candle close, and waits for a retest before entry.
 */
export class BreakAndRetestStrategy implements TradingStrategy {
  public readonly id = 'BREAK_AND_RETEST' as const;
  public readonly name = 'Break and Retest Strategy';
  private config: BreakAndRetestConfig;

  constructor(config?: Partial<BreakAndRetestConfig>) {
    this.config = { ...DEFAULT_CONFIG, ...config };
  }

  public evaluate(snapshot: MultiTimeframeSnapshot): StrategySignal | null {
    const candles5m = (snapshot.candles['5m'] || []).filter((c) => c.isClosed);
    const candles1h = (snapshot.candles['1h'] || []).filter((c) => c.isClosed);
    if (candles5m.length < 30 || candles1h.length < 20) return null;

    const last5m = candles5m[candles5m.length - 1];
    const prev5m = candles5m[candles5m.length - 2];
    const atr = calculateATR(candles5m, 14);
    const currentAtr = atr[atr.length - 1];
    if (!currentAtr || currentAtr <= 0) return null;

    // Identify key horizontal levels from 1H swing highs/lows
    const { swingHighs, swingLows } = identifySwingPoints(candles1h, 3, 3);
    if (swingHighs.length < 2 && swingLows.length < 2) return null;

    const recentResistances = swingHighs.slice(-3).map((s) => s.price);
    const recentSupports = swingLows.slice(-3).map((s) => s.price);

    // Evaluate Resistance Break & Retest (Bullish setup)
    for (const level of recentResistances) {
      // Check if price previously broke above level and is now retesting it as support
      const brokeThrough = prev5m.close > level && candles5m.some((c, idx) => idx < candles5m.length - 2 && c.close > level);
      const retestedLevel = last5m.low <= level + currentAtr * 0.4 && last5m.close >= level && last5m.close > last5m.open;

      if (brokeThrough && retestedLevel) {
        const entryPrice = last5m.close;
        const stopLossPrice = level - currentAtr * this.config.atrStopBuffer;
        const risk = entryPrice - stopLossPrice;
        if (risk <= 0) continue;

        const tp1Price = entryPrice + risk * 1.5;
        const tp2Price = entryPrice + risk * 3.0;

        return {
          strategyId: this.id,
          symbol: snapshot.symbol,
          direction: 'BUY',
          executionTimeframe: '5m',
          higherTimeframeBias: 'BULLISH',
          signalCandleTime: last5m.openTime,
          suggestedEntryPrice: entryPrice,
          stopLossPrice,
          tp1Price,
          tp2Price,
          riskRewardRatio: 3.0,
          qualityScore: 72,
          qualityBreakdown: { horizontalLevelSignificance: 25, retestPrecision: 25, riskReward: 22 },
          relevantTrendlines: [],
          relevantZones: [],
          rationale: `Bullish Break and Retest of established 1H horizontal resistance level at ${level.toFixed(2)}.`
        };
      }
    }

    // Evaluate Support Break & Retest (Bearish setup)
    for (const level of recentSupports) {
      const brokeThrough = prev5m.close < level && candles5m.some((c, idx) => idx < candles5m.length - 2 && c.close < level);
      const retestedLevel = last5m.high >= level - currentAtr * 0.4 && last5m.close <= level && last5m.close < last5m.open;

      if (brokeThrough && retestedLevel) {
        const entryPrice = last5m.close;
        const stopLossPrice = level + currentAtr * this.config.atrStopBuffer;
        const risk = stopLossPrice - entryPrice;
        if (risk <= 0) continue;

        const tp1Price = entryPrice - risk * 1.5;
        const tp2Price = entryPrice - risk * 3.0;

        return {
          strategyId: this.id,
          symbol: snapshot.symbol,
          direction: 'SELL',
          executionTimeframe: '5m',
          higherTimeframeBias: 'BEARISH',
          signalCandleTime: last5m.openTime,
          suggestedEntryPrice: entryPrice,
          stopLossPrice,
          tp1Price,
          tp2Price,
          riskRewardRatio: 3.0,
          qualityScore: 72,
          qualityBreakdown: { horizontalLevelSignificance: 25, retestPrecision: 25, riskReward: 22 },
          relevantTrendlines: [],
          relevantZones: [],
          rationale: `Bearish Break and Retest of established 1H horizontal support level at ${level.toFixed(2)}.`
        };
      }
    }

    return null;
  }
}
