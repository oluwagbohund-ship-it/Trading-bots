import { Candle, Timeframe } from '@crypto-signal/market-data';
import { Trendline, SupplyDemandZone } from '@crypto-signal/indicators';

export type StrategyId =
  | 'TOP_DOWN_TRENDLINE'
  | 'BREAK_AND_RETEST'
  | 'LIQUIDITY_SWEEP_REVERSAL'
  | 'ORDER_BLOCK_RETEST';

export type TradeDirection = 'BUY' | 'SELL';
export type MarketBias = 'BULLISH' | 'BEARISH' | 'NEUTRAL';
export type TrendlineEntryMode = 'BREAK' | 'BOUNCE' | 'RETEST';

export interface MultiTimeframeSnapshot {
  symbol: string;
  timestamp: number;
  candles: Record<Timeframe, Candle[]>; // Strictly closed historical candles up to timestamp
}

export interface StrategySignal {
  strategyId: StrategyId;
  symbol: string;
  direction: TradeDirection;
  entryMode?: TrendlineEntryMode;
  executionTimeframe: '5m';
  higherTimeframeBias: MarketBias;
  signalCandleTime: number;
  suggestedEntryPrice: number; // Next 5M candle open
  stopLossPrice: number;
  tp1Price: number;
  tp2Price: number;
  riskRewardRatio: number;
  qualityScore: number;
  qualityBreakdown: Record<string, number>;
  relevantTrendlines: Trendline[];
  relevantZones: SupplyDemandZone[];
  rationale: string;
}

export interface TradingStrategy {
  readonly id: StrategyId;
  readonly name: string;
  evaluate(snapshot: MultiTimeframeSnapshot): StrategySignal | null;
}
