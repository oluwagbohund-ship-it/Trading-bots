import { Candle, Timeframe } from '@crypto-signal/market-data';
import { SwingPoint } from '../types.js';
import { Trendline, TrendlineDirection, TrendlineTouch } from './types.js';

export interface TrendlineConfig {
  minTouches: number;           // Tori Trades standard: at least 2 anchor points + 3rd touch confirmation (configurable)
  touchTolerancePercent: number; // Max distance from trendline to count as a touch (e.g., 0.002 = 0.2%)
  maxViolationPercent: number;   // Max close beyond trendline before invalidating/breaking
  maxLinesPerDirection: number;  // Keep top cleanest trendlines
}

const DEFAULT_CONFIG: TrendlineConfig = {
  minTouches: 3,
  touchTolerancePercent: 0.0025, // 0.25% tolerance
  maxViolationPercent: 0.001,    // 0.1% close breach confirms structural break
  maxLinesPerDirection: 2
};

export class TrendlineEngine {
  private config: TrendlineConfig;

  constructor(config?: Partial<TrendlineConfig>) {
    this.config = { ...DEFAULT_CONFIG, ...config };
  }

  /**
   * Computes price along the ray at a given timestamp.
   */
  public getPriceAtTime(line: Pick<Trendline, 'anchor1' | 'slope'>, time: number): number {
    return line.anchor1.price + line.slope * (time - line.anchor1.time);
  }

  /**
   * Detects valid ascending and descending trendlines strictly from confirmed swing points
   * up to the current candle index (no lookahead bias).
   */
  public detectTrendlines(
    candles: Candle[],
    swingHighs: SwingPoint[],
    swingLows: SwingPoint[],
    timeframe: Timeframe
  ): Trendline[] {
    if (candles.length === 0) return [];

    const currentIndex = candles.length - 1;
    const ascending = this.buildCandidateLines(candles, swingLows, 'ASCENDING', timeframe, currentIndex);
    const descending = this.buildCandidateLines(candles, swingHighs, 'DESCENDING', timeframe, currentIndex);

    return [
      ...ascending.slice(0, this.config.maxLinesPerDirection),
      ...descending.slice(0, this.config.maxLinesPerDirection)
    ];
  }

  private buildCandidateLines(
    candles: Candle[],
    swings: SwingPoint[],
    direction: TrendlineDirection,
    timeframe: Timeframe,
    currentIndex: number
  ): Trendline[] {
    const candidates: Trendline[] = [];

    // Pair confirmed swing points chronologically
    for (let i = 0; i < swings.length - 1; i++) {
      for (let j = i + 1; j < swings.length; j++) {
        const p1 = swings[i];
        const p2 = swings[j];

        // Ensure points are within available historical range
        if (p2.index > currentIndex || p1.time === p2.time) continue;

        const slope = (p2.price - p1.price) / (p2.time - p1.time);

        // Ascending requires higher lows (positive slope); Descending requires lower highs (negative slope)
        if (direction === 'ASCENDING' && slope <= 0) continue;
        if (direction === 'DESCENDING' && slope >= 0) continue;

        const validation = this.validateRay(candles, p1, p2, slope, direction, currentIndex);
        if (validation.isValid && validation.touches.length >= this.config.minTouches) {
          candidates.push({
            id: `${timeframe}_${direction}_${p1.time}_${p2.time}`,
            timeframe,
            direction,
            anchor1: p1,
            anchor2: p2,
            slope,
            intercept: p1.price,
            touches: validation.touches,
            touchCount: validation.touches.length,
            isValid: true,
            isBroken: validation.isBroken,
            brokenAtTime: validation.brokenAtTime,
            brokenAtIndex: validation.brokenAtIndex
          });
        }
      }
    }

    // Rank by number of qualifying touches and recency of anchor2
    return candidates.sort((a, b) => {
      if (b.touchCount !== a.touchCount) return b.touchCount - a.touchCount;
      return b.anchor2.time - a.anchor2.time;
    });
  }

  private validateRay(
    candles: Candle[],
    anchor1: SwingPoint,
    anchor2: SwingPoint,
    slope: number,
    direction: TrendlineDirection,
    currentIndex: number
  ): { isValid: boolean; touches: TrendlineTouch[]; isBroken: boolean; brokenAtTime?: number; brokenAtIndex?: number } {
    const touches: TrendlineTouch[] = [
      { index: anchor1.index, time: anchor1.time, price: anchor1.price, linePrice: anchor1.price, deviationPercent: 0, isAnchor: true },
      { index: anchor2.index, time: anchor2.time, price: anchor2.price, linePrice: anchor2.price, deviationPercent: 0, isAnchor: true }
    ];

    let isBroken = false;
    let brokenAtTime: number | undefined;
    let brokenAtIndex: number | undefined;

    for (let k = anchor1.index + 1; k <= currentIndex; k++) {
      const c = candles[k];
      if (!c.isClosed && k < currentIndex) continue;

      const linePrice = anchor1.price + slope * (c.openTime - anchor1.time);
      const tolerance = linePrice * this.config.touchTolerancePercent;
      const violationThreshold = linePrice * this.config.maxViolationPercent;

      // Check structural violation (candle body close piercing the trendline)
      if (direction === 'ASCENDING') {
        if (c.isClosed && c.close < linePrice - violationThreshold) {
          // If violated *between* anchor1 and anchor2, the trendline is invalid (cuts through price action)
          if (k <= anchor2.index) {
            return { isValid: false, touches: [], isBroken: true };
          }
          // If violated *after* anchor2, record the breakout event
          if (!isBroken) {
            isBroken = true;
            brokenAtTime = c.openTime;
            brokenAtIndex = k;
          }
        }

        // Check qualifying touch (wick or close tests the line without closing below)
        if (k !== anchor2.index && !isBroken) {
          const dist = Math.abs(c.low - linePrice);
          if (dist <= tolerance && c.close >= linePrice - violationThreshold) {
            touches.push({
              index: k,
              time: c.openTime,
              price: c.low,
              linePrice,
              deviationPercent: dist / linePrice,
              isAnchor: false
            });
          }
        }
      } else {
        // DESCENDING
        if (c.isClosed && c.close > linePrice + violationThreshold) {
          if (k <= anchor2.index) {
            return { isValid: false, touches: [], isBroken: true };
          }
          if (!isBroken) {
            isBroken = true;
            brokenAtTime = c.openTime;
            brokenAtIndex = k;
          }
        }

        if (k !== anchor2.index && !isBroken) {
          const dist = Math.abs(c.high - linePrice);
          if (dist <= tolerance && c.close <= linePrice + violationThreshold) {
            touches.push({
              index: k,
              time: c.openTime,
              price: c.high,
              linePrice,
              deviationPercent: dist / linePrice,
              isAnchor: false
            });
          }
        }
      }
    }

    return { isValid: true, touches, isBroken, brokenAtTime, brokenAtIndex };
  }
}
