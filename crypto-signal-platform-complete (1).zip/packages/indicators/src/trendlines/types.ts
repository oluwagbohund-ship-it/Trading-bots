import { SwingPoint } from '../types.js';
import { Timeframe } from '@crypto-signal/market-data';

export type TrendlineDirection = 'ASCENDING' | 'DESCENDING';

export interface TrendlineTouch {
  index: number;
  time: number;
  price: number;
  linePrice: number;
  deviationPercent: number;
  isAnchor: boolean;
}

export interface Trendline {
  id: string;
  timeframe: Timeframe;
  direction: TrendlineDirection;
  anchor1: SwingPoint;
  anchor2: SwingPoint;
  slope: number;         // Price change per millisecond
  intercept: number;     // Price at time = 0 (or relative to anchor1.time)
  touches: TrendlineTouch[];
  touchCount: number;
  isValid: boolean;
  isBroken: boolean;
  brokenAtTime?: number;
  brokenAtIndex?: number;
}
