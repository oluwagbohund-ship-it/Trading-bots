import { Trendline } from './types.js';
import { TrendlineEngine } from './engine.js';

export interface ProjectedTrendline {
  sourceTrendline: Trendline;
  currentProjectedPrice: number;
  distancePercent: number;
}

/**
 * Projects higher-timeframe trendlines (e.g., 4H or 1D) onto lower execution timeframes (e.g., 5M)
 * using exact timestamp synchronization without future candle leakage.
 */
export function projectTrendlinesToTimestamp(
  engine: TrendlineEngine,
  higherTimeframeLines: Trendline[],
  targetTimestamp: number,
  currentPrice: number
): ProjectedTrendline[] {
  return higherTimeframeLines
    .filter((line) => line.isValid && line.anchor2.time <= targetTimestamp)
    .map((line) => {
      const projectedPrice = engine.getPriceAtTime(line, targetTimestamp);
      const distancePercent = (currentPrice - projectedPrice) / projectedPrice;
      return {
        sourceTrendline: line,
        currentProjectedPrice: projectedPrice,
        distancePercent
      };
    });
}
