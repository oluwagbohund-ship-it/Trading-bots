import { Candle, Timeframe } from '@crypto-signal/market-data';
import { SupplyDemandZone, ZoneType } from './types.js';

export interface SupplyDemandConfig {
  minBaseCandles: number;          // Research spec: ~2 to 5 small candles
  maxBaseCandles: number;
  maxBaseBodyAtrRatio: number;     // Base candles must be relatively small vs ATR
  minDisplacementAtrMultiple: number; // Research spec: >= 2 ATR displacement
  maxZonesPerType: number;
}

const DEFAULT_SD_CONFIG: SupplyDemandConfig = {
  minBaseCandles: 2,
  maxBaseCandles: 5,
  maxBaseBodyAtrRatio: 0.75,
  minDisplacementAtrMultiple: 2.0,
  maxZonesPerType: 2
};

/**
 * Supply & Demand Detection Engine
 * Implements the initial testable research hypothesis:
 * 2-5 small base candles followed by >= 2 ATR displacement.
 */
export class SupplyDemandEngine {
  private config: SupplyDemandConfig;

  constructor(config?: Partial<SupplyDemandConfig>) {
    this.config = { ...DEFAULT_SD_CONFIG, ...config };
  }

  public detectZones(candles: Candle[], atr: number[], timeframe: Timeframe): SupplyDemandZone[] {
    const zones: SupplyDemandZone[] = [];
    if (candles.length < this.config.maxBaseCandles + 2) return zones;

    // Scan chronologically up to the last closed candle
    for (let i = this.config.minBaseCandles; i < candles.length - 1; i++) {
      const dispCandle = candles[i + 1];
      if (!dispCandle.isClosed) continue;

      const currentAtr = atr[i + 1] || atr[i];
      if (!currentAtr || currentAtr <= 0) continue;

      const dispMove = dispCandle.close - dispCandle.open;
      const dispAbs = Math.abs(dispMove);

      // Require displacement of at least 2 ATR
      if (dispAbs < currentAtr * this.config.minDisplacementAtrMultiple) continue;

      // Look back 2 to 5 candles for a tight consolidation base
      let baseCandles: Candle[] = [];
      for (let lookback = 0; lookback < this.config.maxBaseCandles; lookback++) {
        const idx = i - lookback;
        if (idx < 0) break;
        const c = candles[idx];
        const bodySize = Math.abs(c.close - c.open);
        if (bodySize <= currentAtr * this.config.maxBaseBodyAtrRatio) {
          baseCandles.unshift(c);
        } else {
          break;
        }
      }

      if (baseCandles.length < this.config.minBaseCandles) continue;

      const zoneType: ZoneType = dispMove > 0 ? 'DEMAND' : 'SUPPLY';
      const upperBound = Math.max(...baseCandles.map((c) => c.high));
      const lowerBound = Math.min(...baseCandles.map((c) => c.low));

      const zone: SupplyDemandZone = {
        id: `${timeframe}_${zoneType}_${dispCandle.openTime}`,
        timeframe,
        type: zoneType,
        upperBound,
        lowerBound,
        createdAtTime: dispCandle.openTime,
        createdAtIndex: i + 1,
        baseCandleCount: baseCandles.length,
        displacementAtrMultiple: dispAbs / currentAtr,
        isFresh: true,
        retestCount: 0,
        isInvalidated: false
      };

      // Evaluate subsequent closed candles for retests and invalidation
      this.evaluateZoneHistory(zone, candles, i + 2);

      if (!zone.isInvalidated) {
        zones.push(zone);
      }
    }

    // Return freshest, most recent zones up to configured limits
    const supply = zones.filter((z) => z.type === 'SUPPLY').slice(-this.config.maxZonesPerType);
    const demand = zones.filter((z) => z.type === 'DEMAND').slice(-this.config.maxZonesPerType);

    return [...supply, ...demand];
  }

  private evaluateZoneHistory(zone: SupplyDemandZone, candles: Candle[], startIndex: number): void {
    for (let k = startIndex; k < candles.length; k++) {
      const c = candles[k];
      if (!c.isClosed) continue;

      if (zone.type === 'DEMAND') {
        if (c.close < zone.lowerBound) {
          zone.isInvalidated = true;
          zone.invalidatedAtTime = c.openTime;
          return;
        }
        if (c.low <= zone.upperBound && c.close >= zone.lowerBound) {
          zone.retestCount++;
          zone.isFresh = false;
        }
      } else {
        if (c.close > zone.upperBound) {
          zone.isInvalidated = true;
          zone.invalidatedAtTime = c.openTime;
          return;
        }
        if (c.high >= zone.lowerBound && c.close <= zone.upperBound) {
          zone.retestCount++;
          zone.isFresh = false;
        }
      }
    }
  }
}
