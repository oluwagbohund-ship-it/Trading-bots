import { Timeframe } from '@crypto-signal/market-data';

export type ZoneType = 'SUPPLY' | 'DEMAND';

export interface SupplyDemandZone {
  id: string;
  timeframe: Timeframe;
  type: ZoneType;
  upperBound: number;
  lowerBound: number;
  createdAtTime: number;
  createdAtIndex: number;
  baseCandleCount: number;
  displacementAtrMultiple: number;
  isFresh: boolean;
  retestCount: number;
  isInvalidated: boolean;
  invalidatedAtTime?: number;
}
