import { Candle } from '@crypto-signal/market-data';

export function calculateATR(candles: Candle[], period = 14): number[] {
  if (candles.length === 0) return [];

  const trueRanges: number[] = [];
  for (let i = 0; i < candles.length; i++) {
    const current = candles[i];
    if (i === 0) {
      trueRanges.push(current.high - current.low);
      continue;
    }
    const prevClose = candles[i - 1].close;
    const tr = Math.max(
      current.high - current.low,
      Math.abs(current.high - prevClose),
      Math.abs(current.low - prevClose)
    );
    trueRanges.push(tr);
  }

  const atr: number[] = [];
  let currentAtr = 0;

  for (let i = 0; i < trueRanges.length; i++) {
    if (i < period - 1) {
      atr.push(0);
    } else if (i === period - 1) {
      const sum = trueRanges.slice(0, period).reduce((a, b) => a + b, 0);
      currentAtr = sum / period;
      atr.push(currentAtr);
    } else {
      currentAtr = (currentAtr * (period - 1) + trueRanges[i]) / period;
      atr.push(currentAtr);
    }
  }

  return atr;
}
