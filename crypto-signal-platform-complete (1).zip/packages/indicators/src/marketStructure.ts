import { Candle } from '@crypto-signal/market-data';
import { SwingPoint } from './types.js';

export function identifySwingPoints(candles: Candle[], leftBars = 5, rightBars = 5): { swingHighs: SwingPoint[], swingLows: SwingPoint[] } {
  const swingHighs: SwingPoint[] = [];
  const swingLows: SwingPoint[] = [];

  if (candles.length < leftBars + rightBars + 1) {
    return { swingHighs, swingLows };
  }

  for (let i = leftBars; i < candles.length - rightBars; i++) {
    const current = candles[i];
    
    // Check Swing High
    let isHigh = true;
    for (let j = i - leftBars; j <= i + rightBars; j++) {
      if (j === i) continue;
      if (candles[j].high >= current.high) {
        isHigh = false;
        break;
      }
    }
    if (isHigh) {
      swingHighs.push({
        index: i,
        time: current.openTime,
        price: current.high,
        type: 'HIGH'
      });
    }

    // Check Swing Low
    let isLow = true;
    for (let j = i - leftBars; j <= i + rightBars; j++) {
      if (j === i) continue;
      if (candles[j].low <= current.low) {
        isLow = false;
        break;
      }
    }
    if (isLow) {
      swingLows.push({
        index: i,
        time: current.openTime,
        price: current.low,
        type: 'LOW'
      });
    }
  }

  return { swingHighs, swingLows };
}
