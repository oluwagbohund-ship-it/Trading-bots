import { Candle } from '@crypto-signal/market-data';

export interface SwingPoint {
  index: number;
  time: number;
  price: number;
  type: 'HIGH' | 'LOW';
}

export interface IndicatorResult {
  atr: number[];
  swingHighs: SwingPoint[];
  swingLows: SwingPoint[];
}
