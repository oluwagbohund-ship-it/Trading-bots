import { Candle, Timeframe } from '@crypto-signal/market-data';
import { TradingStrategy, MultiTimeframeSnapshot, StrategySignal } from '@crypto-signal/strategies';
import { RiskManager, AccountState } from '@crypto-signal/risk-engine';
import { BacktestConfig, SimulatedTrade, PerformanceReport } from './types.js';

const DEFAULT_CONFIG: BacktestConfig = {
  initialBalance: 1000,
  feeRate: 0.0005,
  slippageRate: 0.0002,
  tp1Allocation: 0.4,
  tp2Allocation: 0.4,
  tp3Allocation: 0.2,
  moveStopToBeAt1R: true
};

interface ActivePosition {
  id: string;
  signal: StrategySignal;
  entryTime: number;
  entryPrice: number;
  currentStopLoss: number;
  initialStopLoss: number;
  tp1Price: number;
  tp2Price: number;
  tp3Price: number;
  initialQuantity: number;
  remainingQuantity: number;
  riskAmountUsd: number;
  tp1Hit: boolean;
  tp2Hit: boolean;
  tp3Hit: boolean;
  beMoved: boolean;
  realizedPnlUsd: number;
  feesPaidUsd: number;
}

/**
 * Event-Driven Historical Backtesting Engine
 * - Strictly chronological processing without future candle access (zero lookahead bias)
 * - Next-candle-open entry execution
 * - Conservative same-candle SL/TP tie-breaking (assumes SL occurs first)
 */
export class EventDrivenBacktester {
  private config: BacktestConfig;
  private riskManager: RiskManager;

  constructor(config?: Partial<BacktestConfig>) {
    this.config = { ...DEFAULT_CONFIG, ...config };
    this.riskManager = new RiskManager();
  }

  public run(
    strategy: TradingStrategy,
    symbol: string,
    candlesByTf: Record<Timeframe, Candle[]>
  ): PerformanceReport {
    const candles5m = (candlesByTf['5m'] || []).filter((c) => c.isClosed);
    let balance = this.config.initialBalance;
    let peakEquity = balance;
    let maxDrawdownPercent = 0;

    const equityCurve: { time: number; equity: number }[] = [];
    const completedTrades: SimulatedTrade[] = [];

    let pendingSignal: StrategySignal | null = null;
    let activePos: ActivePosition | null = null;
    let tradeCounter = 0;

    // Chronological bar-by-bar loop on 5M execution timeframe
    for (let i = 50; i < candles5m.length; i++) {
      const currentBar = candles5m[i];

      // 1. Execute pending signal at current bar OPEN (next-candle-open rule)
      if (pendingSignal && !activePos) {
        const slippageFactor = pendingSignal.direction === 'BUY'
          ? 1 + this.config.slippageRate
          : 1 - this.config.slippageRate;
        const fillPrice = currentBar.open * slippageFactor;

        const accountState: AccountState = {
          accountId: 'backtest_account',
          balance,
          riskPercentage: 1.0,
          openPositionsCount: 0,
          maxOpenTrades: 1,
          dailyLossUsd: 0,
          maxDailyLossUsd: balance * 0.05
        };

        // Re-align signal entry with actual next-open fill price for exact sizing
        const adjustedSignal: StrategySignal = {
          ...pendingSignal,
          suggestedEntryPrice: fillPrice
        };

        const sizing = this.riskManager.evaluateTradeRisk(accountState, adjustedSignal);
        if (sizing.approved && sizing.contractQuantity > 0) {
          const entryFee = sizing.contractQuantity * fillPrice * this.config.feeRate;
          balance -= entryFee;
          tradeCounter++;

          activePos = {
            id: `BT_${strategy.id}_${tradeCounter}`,
            signal: adjustedSignal,
            entryTime: currentBar.openTime,
            entryPrice: fillPrice,
            currentStopLoss: adjustedSignal.stopLossPrice,
            initialStopLoss: adjustedSignal.stopLossPrice,
            tp1Price: sizing.tp1Price,
            tp2Price: sizing.tp2Price,
            tp3Price: sizing.tp3Price,
            initialQuantity: sizing.contractQuantity,
            remainingQuantity: sizing.contractQuantity,
            riskAmountUsd: sizing.riskAmountUsd,
            tp1Hit: false,
            tp2Hit: false,
            tp3Hit: false,
            beMoved: false,
            realizedPnlUsd: -entryFee,
            feesPaidUsd: entryFee
          };
        }
        pendingSignal = null;
      }

      // 2. Manage active position on current bar
      if (activePos) {
        const closedTrade = this.processBarForPosition(activePos, currentBar, (pnlDelta, feeDelta) => {
          balance += pnlDelta - feeDelta;
          activePos!.realizedPnlUsd += pnlDelta - feeDelta;
          activePos!.feesPaidUsd += feeDelta;
        });

        if (closedTrade) {
          completedTrades.push(closedTrade);
          activePos = null;
        }
      }

      // 3. Record equity curve & drawdown
      if (balance > peakEquity) peakEquity = balance;
      const dd = peakEquity > 0 ? ((peakEquity - balance) / peakEquity) * 100 : 0;
      if (dd > maxDrawdownPercent) maxDrawdownPercent = dd;

      equityCurve.push({ time: currentBar.openTime, equity: balance });

      // 4. Evaluate strategy using strictly closed candles up to currentBar.closeTime (no lookahead)
      if (!activePos && !pendingSignal && i < candles5m.length - 1) {
        const snapshot = this.buildPointInTimeSnapshot(symbol, currentBar.closeTime, candlesByTf, candles5m, i);
        const signal = strategy.evaluate(snapshot);
        if (signal) {
          pendingSignal = signal;
        }
      }
    }

    // Close any remaining open position at end of data
    if (activePos && candles5m.length > 0) {
      const lastBar = candles5m[candles5m.length - 1];
      const pnl = this.computePnl(activePos.signal.direction, activePos.entryPrice, lastBar.close, activePos.remainingQuantity);
      const exitFee = activePos.remainingQuantity * lastBar.close * this.config.feeRate;
      balance += pnl - exitFee;
      activePos.realizedPnlUsd += pnl - exitFee;
      activePos.feesPaidUsd += exitFee;

      completedTrades.push(this.finalizeTrade(activePos, lastBar.closeTime, lastBar.close, 'END_OF_DATA'));
    }

    return this.buildPerformanceReport(strategy.id, symbol, balance, maxDrawdownPercent, equityCurve, completedTrades);
  }

  private buildPointInTimeSnapshot(
    symbol: string,
    decisionCloseTime: number,
    candlesByTf: Record<Timeframe, Candle[]>,
    candles5m: Candle[],
    current5mIndex: number
  ): MultiTimeframeSnapshot {
    // Only include candles whose closeTime <= decisionCloseTime (eliminates lookahead bias)
    const filterClosedAtTime = (arr?: Candle[]) =>
      (arr || []).filter((c) => c.isClosed && c.closeTime <= decisionCloseTime);

    return {
      symbol,
      timestamp: decisionCloseTime,
      candles: {
        '1m': filterClosedAtTime(candlesByTf['1m']),
        '5m': candles5m.slice(0, current5mIndex + 1),
        '1h': filterClosedAtTime(candlesByTf['1h']),
        '4h': filterClosedAtTime(candlesByTf['4h']),
        '1d': filterClosedAtTime(candlesByTf['1d']),
        '1w': filterClosedAtTime(candlesByTf['1w']),
        '1M': filterClosedAtTime(candlesByTf['1M'])
      }
    };
  }

  private processBarForPosition(
    pos: ActivePosition,
    bar: Candle,
    onPartialFill: (pnlDelta: number, feeDelta: number) => void
  ): SimulatedTrade | null {
    const isBuy = pos.signal.direction === 'BUY';

    // Conservative Rule: Check Stop Loss FIRST before Take Profit within the same candle
    const stopHit = isBuy ? bar.low <= pos.currentStopLoss : bar.high >= pos.currentStopLoss;
    if (stopHit) {
      const exitPrice = pos.currentStopLoss;
      const pnl = this.computePnl(pos.signal.direction, pos.entryPrice, exitPrice, pos.remainingQuantity);
      const fee = pos.remainingQuantity * exitPrice * this.config.feeRate;
      onPartialFill(pnl, fee);
      pos.remainingQuantity = 0;
      const reason = pos.beMoved ? 'TRAILING_STOP' : 'STOP_LOSS';
      return this.finalizeTrade(pos, bar.closeTime, exitPrice, reason);
    }

    // Check +1R break-even rule
    const initialRiskPerUnit = Math.abs(pos.entryPrice - pos.initialStopLoss);
    const oneRPrice = isBuy ? pos.entryPrice + initialRiskPerUnit : pos.entryPrice - initialRiskPerUnit;
    const reached1R = isBuy ? bar.high >= oneRPrice : bar.low <= oneRPrice;
    if (this.config.moveStopToBeAt1R && !pos.beMoved && reached1R) {
      pos.currentStopLoss = pos.entryPrice;
      pos.beMoved = true;
    }

    // Check TP1
    if (!pos.tp1Hit) {
      const tp1Reached = isBuy ? bar.high >= pos.tp1Price : bar.low <= pos.tp1Price;
      if (tp1Reached) {
        const qty = pos.initialQuantity * this.config.tp1Allocation;
        const pnl = this.computePnl(pos.signal.direction, pos.entryPrice, pos.tp1Price, qty);
        const fee = qty * pos.tp1Price * this.config.feeRate;
        onPartialFill(pnl, fee);
        pos.remainingQuantity -= qty;
        pos.tp1Hit = true;
      }
    }

    // Check TP2
    if (!pos.tp2Hit && pos.remainingQuantity > 0) {
      const tp2Reached = isBuy ? bar.high >= pos.tp2Price : bar.low <= pos.tp2Price;
      if (tp2Reached) {
        const qty = pos.initialQuantity * this.config.tp2Allocation;
        const pnl = this.computePnl(pos.signal.direction, pos.entryPrice, pos.tp2Price, qty);
        const fee = qty * pos.tp2Price * this.config.feeRate;
        onPartialFill(pnl, fee);
        pos.remainingQuantity -= qty;
        pos.tp2Hit = true;
      }
    }

    // Check TP3 (Final runner exit)
    if (!pos.tp3Hit && pos.remainingQuantity > 0) {
      const tp3Reached = isBuy ? bar.high >= pos.tp3Price : bar.low <= pos.tp3Price;
      if (tp3Reached) {
        const qty = pos.remainingQuantity;
        const pnl = this.computePnl(pos.signal.direction, pos.entryPrice, pos.tp3Price, qty);
        const fee = qty * pos.tp3Price * this.config.feeRate;
        onPartialFill(pnl, fee);
        pos.remainingQuantity = 0;
        pos.tp3Hit = true;
        return this.finalizeTrade(pos, bar.closeTime, pos.tp3Price, 'TP3_TARGET');
      }
    }

    return null;
  }

  private computePnl(direction: 'BUY' | 'SELL', entry: number, exit: number, qty: number): number {
    return direction === 'BUY' ? (exit - entry) * qty : (entry - exit) * qty;
  }

  private finalizeTrade(
    pos: ActivePosition,
    exitTime: number,
    exitPrice: number,
    exitReason: SimulatedTrade['exitReason']
  ): SimulatedTrade {
    const rMultiple = pos.riskAmountUsd > 0 ? pos.realizedPnlUsd / pos.riskAmountUsd : 0;
    return {
      id: pos.id,
      strategyId: pos.signal.strategyId,
      symbol: pos.signal.symbol,
      direction: pos.signal.direction,
      entryTime: pos.entryTime,
      entryPrice: pos.entryPrice,
      exitTime,
      exitPrice,
      initialStopLoss: pos.initialStopLoss,
      tp1Price: pos.tp1Price,
      tp2Price: pos.tp2Price,
      tp3Price: pos.tp3Price,
      quantity: pos.initialQuantity,
      remainingQuantity: pos.remainingQuantity,
      tp1Hit: pos.tp1Hit,
      tp2Hit: pos.tp2Hit,
      tp3Hit: pos.tp3Hit,
      realizedPnlUsd: pos.realizedPnlUsd,
      feesPaidUsd: pos.feesPaidUsd,
      rMultiple,
      durationMs: Math.max(0, exitTime - pos.entryTime),
      exitReason
    };
  }

  private buildPerformanceReport(
    strategyId: any,
    symbol: string,
    finalBalance: number,
    maxDrawdownPercent: number,
    equityCurve: { time: number; equity: number }[],
    trades: SimulatedTrade[]
  ): PerformanceReport {
    const totalTrades = trades.length;
    const winners = trades.filter((t) => t.realizedPnlUsd > 0);
    const losers = trades.filter((t) => t.realizedPnlUsd <= 0);

    const grossProfitUsd = winners.reduce((sum, t) => sum + t.realizedPnlUsd, 0);
    const grossLossUsd = Math.abs(losers.reduce((sum, t) => sum + t.realizedPnlUsd, 0));
    const netProfitUsd = finalBalance - this.config.initialBalance;

    const profitFactor = grossLossUsd > 0 ? grossProfitUsd / grossLossUsd : grossProfitUsd > 0 ? Infinity : 0;
    const winRatePercent = totalTrades > 0 ? (winners.length / totalTrades) * 100 : 0;
    const expectancyUsd = totalTrades > 0 ? netProfitUsd / totalTrades : 0;
    const averageR = totalTrades > 0 ? trades.reduce((sum, t) => sum + t.rMultiple, 0) / totalTrades : 0;
    const averageDurationMs = totalTrades > 0 ? trades.reduce((sum, t) => sum + t.durationMs, 0) / totalTrades : 0;

    let maxConsecutiveLosses = 0;
    let currentLossStreak = 0;
    for (const t of trades) {
      if (t.realizedPnlUsd <= 0) {
        currentLossStreak++;
        if (currentLossStreak > maxConsecutiveLosses) maxConsecutiveLosses = currentLossStreak;
      } else {
        currentLossStreak = 0;
      }
    }

    return {
      strategyId,
      symbol,
      initialBalance: this.config.initialBalance,
      finalBalance,
      totalTrades,
      winningTrades: winners.length,
      losingTrades: losers.length,
      winRatePercent,
      grossProfitUsd,
      grossLossUsd,
      netProfitUsd,
      profitFactor,
      expectancyUsd,
      averageR,
      maxDrawdownPercent,
      maxConsecutiveLosses,
      averageDurationMs,
      equityCurve,
      trades
    };
  }
}
