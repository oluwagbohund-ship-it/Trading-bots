import { Candle, Timeframe } from '@crypto-signal/market-data';
import {
  ReplayPlaybackState,
  ManualTrendlineAnnotation,
  ManualHorizontalLevel,
  ManualZoneAnnotation,
  PaperTradeOrder,
  PaperPosition,
  JournalEntry,
  ReplaySnapshot
} from './types.js';

/**
 * Historical Candle Replay & Manual Paper-Trading Engine
 * - Enforces strict chronological visibility (future candles are never exposed)
 * - Supports Play, Pause, Resume, Step Forward, and configurable playback speed
 * - Includes manual chart annotations (max 4 trendlines, 3 horizontal levels, 2 zones)
 * - Includes simulated 1% risk paper-trading execution and trading journal
 */
export class HistoricalReplayEngine {
  private symbol: string;
  private timeframe: Timeframe;
  private allCandles: Candle[];
  private currentIndex: number;
  private playbackState: ReplayPlaybackState = 'PAUSED';
  private playbackSpeedMs = 1000;
  private timer: ReturnType<typeof setInterval> | null = null;

  private accountBalance: number;
  private riskPercent = 0.01; // Fixed 1% risk rule
  private openPositions: PaperPosition[] = [];
  private closedPositions: PaperPosition[] = [];

  private trendlines: ManualTrendlineAnnotation[] = [];
  private horizontalLevels: ManualHorizontalLevel[] = [];
  private zones: ManualZoneAnnotation[] = [];
  private journal: JournalEntry[] = [];

  constructor(
    symbol: string,
    timeframe: Timeframe,
    historicalCandles: Candle[],
    startDateTimestamp?: number,
    initialBalance = 1000
  ) {
    this.symbol = symbol;
    this.timeframe = timeframe;
    this.allCandles = [...historicalCandles].sort((a, b) => a.openTime - b.openTime);
    this.accountBalance = initialBalance;

    if (this.allCandles.length === 0) {
      this.currentIndex = -1;
      this.playbackState = 'ENDED';
    } else if (startDateTimestamp !== undefined) {
      const idx = this.allCandles.findIndex((c) => c.openTime >= startDateTimestamp);
      this.currentIndex = idx >= 0 ? idx : 0;
    } else {
      this.currentIndex = Math.min(30, this.allCandles.length - 1);
    }
  }

  public getVisibleCandles(): Candle[] {
    if (this.currentIndex < 0) return [];
    // Strictly slice up to currentIndex so future candles cannot be accessed
    return this.allCandles.slice(0, this.currentIndex + 1);
  }

  public getCurrentCandle(): Candle | null {
    if (this.currentIndex < 0 || this.currentIndex >= this.allCandles.length) return null;
    return this.allCandles[this.currentIndex];
  }

  public stepForward(onTick?: (snapshot: ReplaySnapshot) => void): boolean {
    if (this.currentIndex >= this.allCandles.length - 1) {
      this.pause();
      this.playbackState = 'ENDED';
      onTick?.(this.getSnapshot());
      return false;
    }

    this.currentIndex++;
    const bar = this.allCandles[this.currentIndex];
    this.evaluatePaperPositionsOnBar(bar);

    if (this.currentIndex >= this.allCandles.length - 1) {
      this.pause();
      this.playbackState = 'ENDED';
    }

    onTick?.(this.getSnapshot());
    return true;
  }

  public play(onTick?: (snapshot: ReplaySnapshot) => void): void {
    if (this.playbackState === 'ENDED') return;
    this.pause();
    this.playbackState = 'PLAYING';
    this.timer = setInterval(() => {
      const moved = this.stepForward(onTick);
      if (!moved) this.pause();
    }, this.playbackSpeedMs);
  }

  public pause(): void {
    if (this.timer) {
      clearInterval(this.timer);
      this.timer = null;
    }
    if (this.playbackState === 'PLAYING') {
      this.playbackState = 'PAUSED';
    }
  }

  public resume(onTick?: (snapshot: ReplaySnapshot) => void): void {
    if (this.playbackState === 'PAUSED') {
      this.play(onTick);
    }
  }

  public setSpeed(speedMs: number, onTick?: (snapshot: ReplaySnapshot) => void): void {
    this.playbackSpeedMs = Math.max(50, speedMs);
    if (this.playbackState === 'PLAYING') {
      this.play(onTick);
    }
  }

  // --- Manual Chart Overlays (Respecting UI Overlay Limits) ---

  public addTrendline(line: ManualTrendlineAnnotation): void {
    if (this.trendlines.length >= 4) {
      this.trendlines.shift(); // Enforce max 4 trendlines
    }
    this.trendlines.push(line);
  }

  public addHorizontalLevel(level: ManualHorizontalLevel): void {
    if (this.horizontalLevels.length >= 3) {
      this.horizontalLevels.shift(); // Enforce max 3 horizontal levels
    }
    this.horizontalLevels.push(level);
  }

  public addZone(zone: ManualZoneAnnotation): void {
    if (this.zones.length >= 2) {
      this.zones.shift(); // Enforce max 2 supply/demand zones
    }
    this.zones.push(zone);
  }

  public clearAnnotations(): void {
    this.trendlines = [];
    this.horizontalLevels = [];
    this.zones = [];
  }

  // --- Manual Paper Trading ---

  public openManualPaperTrade(order: PaperTradeOrder): PaperPosition {
    const bar = this.getCurrentCandle();
    if (!bar) {
      throw new Error('Cannot place paper trade without an active historical bar.');
    }

    if (this.openPositions.length >= 1) {
      throw new Error('Maximum one open paper trade per symbol is allowed.');
    }

    const entryPrice = bar.close;
    const stopDistance = Math.abs(entryPrice - order.stopLossPrice);
    if (stopDistance <= 0) {
      throw new Error('Stop loss must differ from entry price.');
    }

    const rewardDistance = Math.abs(order.tp2Price - entryPrice);
    const rr = rewardDistance / stopDistance;
    if (rr < 2.0) {
      throw new Error(`Minimum 1:2 Risk/Reward required (got 1:${rr.toFixed(2)}).`);
    }

    const riskAmountUsd = this.accountBalance * this.riskPercent;
    const quantity = riskAmountUsd / stopDistance;

    const position: PaperPosition = {
      id: `PAPER_${Date.now()}_${this.openPositions.length + this.closedPositions.length + 1}`,
      symbol: this.symbol,
      direction: order.direction,
      entryTime: bar.closeTime,
      entryPrice,
      stopLossPrice: order.stopLossPrice,
      tp1Price: order.tp1Price,
      tp2Price: order.tp2Price,
      tp3Price: order.tp3Price,
      quantity,
      riskAmountUsd,
      status: 'OPEN',
      realizedPnlUsd: 0,
      notes: order.notes
    };

    this.openPositions.push(position);
    return position;
  }

  public updateStopLoss(positionId: string, newStopLoss: number): void {
    const pos = this.openPositions.find((p) => p.id === positionId);
    if (!pos) throw new Error('Open paper position not found.');
    pos.stopLossPrice = newStopLoss;
  }

  public closePaperPositionManually(positionId: string): PaperPosition {
    const idx = this.openPositions.findIndex((p) => p.id === positionId);
    if (idx === -1) throw new Error('Open paper position not found.');
    const bar = this.getCurrentCandle();
    if (!bar) throw new Error('No active bar to close position.');

    const pos = this.openPositions[idx];
    const pnl =
      pos.direction === 'BUY'
        ? (bar.close - pos.entryPrice) * pos.quantity
        : (pos.entryPrice - bar.close) * pos.quantity;

    pos.status = 'CLOSED';
    pos.exitTime = bar.closeTime;
    pos.exitPrice = bar.close;
    pos.realizedPnlUsd = pnl;
    pos.exitReason = 'MANUAL_CLOSE';

    this.accountBalance += pnl;
    this.openPositions.splice(idx, 1);
    this.closedPositions.push(pos);
    return pos;
  }

  private evaluatePaperPositionsOnBar(bar: Candle): void {
    for (let i = this.openPositions.length - 1; i >= 0; i--) {
      const pos = this.openPositions[i];
      const isBuy = pos.direction === 'BUY';

      // Conservative rule: Stop Loss checked first
      const stopHit = isBuy ? bar.low <= pos.stopLossPrice : bar.high >= pos.stopLossPrice;
      if (stopHit) {
        const pnl = isBuy
          ? (pos.stopLossPrice - pos.entryPrice) * pos.quantity
          : (pos.entryPrice - pos.stopLossPrice) * pos.quantity;

        pos.status = 'CLOSED';
        pos.exitTime = bar.closeTime;
        pos.exitPrice = pos.stopLossPrice;
        pos.realizedPnlUsd = pnl;
        pos.exitReason = 'STOP_LOSS';

        this.accountBalance += pnl;
        this.openPositions.splice(i, 1);
        this.closedPositions.push(pos);
        continue;
      }

      // Check final target hit
      const targetHit = isBuy ? bar.high >= pos.tp2Price : bar.low <= pos.tp2Price;
      if (targetHit) {
        const pnl = isBuy
          ? (pos.tp2Price - pos.entryPrice) * pos.quantity
          : (pos.entryPrice - pos.tp2Price) * pos.quantity;

        pos.status = 'CLOSED';
        pos.exitTime = bar.closeTime;
        pos.exitPrice = pos.tp2Price;
        pos.realizedPnlUsd = pnl;
        pos.exitReason = 'TAKE_PROFIT';

        this.accountBalance += pnl;
        this.openPositions.splice(i, 1);
        this.closedPositions.push(pos);
      }
    }
  }

  // --- Trading Journal ---

  public addJournalEntry(entry: Omit<JournalEntry, 'id' | 'timestamp' | 'symbol' | 'timeframe'>): JournalEntry {
    const bar = this.getCurrentCandle();
    const record: JournalEntry = {
      id: `JRN_${Date.now()}_${this.journal.length + 1}`,
      timestamp: bar ? bar.closeTime : Date.now(),
      symbol: this.symbol,
      timeframe: this.timeframe,
      ...entry
    };
    this.journal.push(record);
    return record;
  }

  public getSnapshot(): ReplaySnapshot {
    return {
      symbol: this.symbol,
      timeframe: this.timeframe,
      playbackState: this.playbackState,
      playbackSpeedMs: this.playbackSpeedMs,
      currentIndex: this.currentIndex,
      totalCandles: this.allCandles.length,
      visibleCandles: this.getVisibleCandles(),
      accountBalance: this.accountBalance,
      openPositions: [...this.openPositions],
      closedPositions: [...this.closedPositions],
      trendlines: [...this.trendlines],
      horizontalLevels: [...this.horizontalLevels],
      zones: [...this.zones],
      journal: [...this.journal]
    };
  }
}
