import { Candle, Timeframe } from '@crypto-signal/market-data';
import { TradeDirection } from '@crypto-signal/strategies';

export type ReplayPlaybackState = 'IDLE' | 'PLAYING' | 'PAUSED' | 'ENDED';

export interface ManualTrendlineAnnotation {
  id: string;
  timeframe: Timeframe;
  startTime: number;
  startPrice: number;
  endTime: number;
  endPrice: number;
  label?: string;
}

export interface ManualHorizontalLevel {
  id: string;
  timeframe: Timeframe;
  price: number;
  label?: string;
}

export interface ManualZoneAnnotation {
  id: string;
  timeframe: Timeframe;
  type: 'SUPPLY' | 'DEMAND';
  startTime: number;
  endTime: number;
  upperPrice: number;
  lowerPrice: number;
  label?: string;
}

export interface PaperTradeOrder {
  direction: TradeDirection;
  stopLossPrice: number;
  tp1Price: number;
  tp2Price: number;
  tp3Price: number;
  notes?: string;
}

export interface PaperPosition {
  id: string;
  symbol: string;
  direction: TradeDirection;
  entryTime: number;
  entryPrice: number;
  stopLossPrice: number;
  tp1Price: number;
  tp2Price: number;
  tp3Price: number;
  quantity: number;
  riskAmountUsd: number;
  status: 'OPEN' | 'CLOSED';
  exitTime?: number;
  exitPrice?: number;
  realizedPnlUsd: number;
  exitReason?: string;
  notes?: string;
}

export interface JournalEntry {
  id: string;
  timestamp: number;
  symbol: string;
  timeframe: Timeframe;
  tradeId?: string;
  title: string;
  notes: string;
  tags: string[];
}

export interface ReplaySnapshot {
  symbol: string;
  timeframe: Timeframe;
  playbackState: ReplayPlaybackState;
  playbackSpeedMs: number;
  currentIndex: number;
  totalCandles: number;
  visibleCandles: Candle[]; // Strictly hides future candles beyond currentIndex
  accountBalance: number;
  openPositions: PaperPosition[];
  closedPositions: PaperPosition[];
  trendlines: ManualTrendlineAnnotation[];
  horizontalLevels: ManualHorizontalLevel[];
  zones: ManualZoneAnnotation[];
  journal: JournalEntry[];
}
