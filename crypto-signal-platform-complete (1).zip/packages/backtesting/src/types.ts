import { StrategyId, TradeDirection } from '@crypto-signal/strategies';

export interface BacktestConfig {
  initialBalance: number;
  feeRate: number;            // e.g. 0.0005 (0.05%)
  slippageRate: number;       // e.g. 0.0002 (0.02%)
  tp1Allocation: number;      // e.g. 0.40 (40%)
  tp2Allocation: number;      // e.g. 0.40 (40%)
  tp3Allocation: number;      // e.g. 0.20 (20% trailing runner)
  moveStopToBeAt1R: boolean;
}

export interface SimulatedTrade {
  id: string;
  strategyId: StrategyId;
  symbol: string;
  direction: TradeDirection;
  entryTime: number;
  entryPrice: number;
  exitTime: number;
  exitPrice: number;
  initialStopLoss: number;
  tp1Price: number;
  tp2Price: number;
  tp3Price: number;
  quantity: number;
  remainingQuantity: number;
  tp1Hit: boolean;
  tp2Hit: boolean;
  tp3Hit: boolean;
  realizedPnlUsd: number;
  feesPaidUsd: number;
  rMultiple: number;
  durationMs: number;
  exitReason: 'STOP_LOSS' | 'TP3_TARGET' | 'TRAILING_STOP' | 'END_OF_DATA';
}

export interface PerformanceReport {
  strategyId: StrategyId;
  symbol: string;
  initialBalance: number;
  finalBalance: number;
  totalTrades: number;
  winningTrades: number;
  losingTrades: number;
  winRatePercent: number;
  grossProfitUsd: number;
  grossLossUsd: number;
  netProfitUsd: number;
  profitFactor: number;
  expectancyUsd: number;
  averageR: number;
  maxDrawdownPercent: number;
  maxConsecutiveLosses: number;
  averageDurationMs: number;
  equityCurve: { time: number; equity: number }[];
  trades: SimulatedTrade[];
}
