import { ChartRenderOptions } from './types.js';

/**
 * Server-Side SVG Chart Renderer
 * Generates clean, annotated Binance-styled chart snapshots as SVG strings (convertible to Buffer)
 * guaranteed to match the exact market snapshot and signal prices.
 */
export class ServerSideChartRenderer {
  public renderSvg(options: ChartRenderOptions): string {
    const { width, height, symbol, timeframe, candles, signal } = options;
    if (candles.length === 0) return `<svg width="${width}" height="${height}"></svg>`;

    const padding = { top: 40, right: 80, bottom: 40, left: 20 };
    const chartWidth = width - padding.left - padding.right;
    const chartHeight = height - padding.top - padding.bottom;

    const highs = candles.map((c) => c.high);
    const lows = candles.map((c) => c.low);
    let minPrice = Math.min(...lows);
    let maxPrice = Math.max(...highs);

    // Include trade levels in price scale range
    minPrice = Math.min(minPrice, signal.stopLossPrice, signal.suggestedEntryPrice);
    maxPrice = Math.max(maxPrice, signal.tp2Price, signal.tp3Price);

    const priceRange = maxPrice - minPrice || 1;
    const candleWidth = Math.max(2, chartWidth / candles.length - 2);

    const priceToY = (price: number) => padding.top + chartHeight - ((price - minPrice) / priceRange) * chartHeight;
    const timeToX = (index: number) => padding.left + index * (chartWidth / candles.length);

    let svg = `<svg xmlns="http://www.w3.org/2000/svg" width="${width}" height="${height}" viewBox="0 0 ${width} ${height}" style="background-color:#0B0E11; font-family:-apple-system, sans-serif;">`;

    // Grid lines
    for (let i = 1; i <= 4; i++) {
      const y = padding.top + (chartHeight / 5) * i;
      svg += `<line x1="${padding.left}" y1="${y}" x2="${width - padding.right}" y2="${y}" stroke="#1E2329" stroke-width="1" />`;
    }

    // Candlesticks (Bullish: #0ECB81, Bearish: #F6465D)
    candles.forEach((c, idx) => {
      const x = timeToX(idx) + candleWidth / 2;
      const isBull = c.close >= c.open;
      const color = isBull ? '#0ECB81' : '#F6465D';

      const yHigh = priceToY(c.high);
      const yLow = priceToY(c.low);
      const yOpen = priceToY(c.open);
      const yClose = priceToY(c.close);

      // Wick
      svg += `<line x1="${x}" y1="${yHigh}" x2="${x}" y2="${yLow}" stroke="${color}" stroke-width="1" />`;
      // Body
      const bodyY = Math.min(yOpen, yClose);
      const bodyHeight = Math.max(2, Math.abs(yOpen - yClose));
      svg += `<rect x="${x - candleWidth / 2}" y="${bodyY}" width="${candleWidth}" height="${bodyHeight}" fill="${color}" rx="1" />`;
    });

    // Trendlines
    signal.relevantTrendlines.forEach((tl) => {
      const x1 = timeToX(0);
      const x2 = width - padding.right;
      const y1 = priceToY(tl.anchor1.price);
      const y2 = priceToY(tl.anchor2.price + tl.slope * (candles[candles.length - 1].openTime - tl.anchor2.time));
      const color = tl.direction === 'ASCENDING' ? '#0ECB81' : '#F6465D';
      svg += `<line x1="${x1}" y1="${y1}" x2="${x2}" y2="${y2}" stroke="${color}" stroke-width="1.5" stroke-dasharray="4,2" />`;
    });

    // Horizontal levels (Yellow #FCD535)
    signal.relevantZones.forEach((z) => {
      const yUpper = priceToY(z.upperBound);
      const yLower = priceToY(z.lowerBound);
      const fillColor = z.type === 'DEMAND' ? 'rgba(14,203,129,0.12)' : 'rgba(246,70,93,0.12)';
      svg += `<rect x="${padding.left}" y="${yUpper}" width="${chartWidth}" height="${Math.abs(yLower - yUpper)}" fill="${fillColor}" />`;
    });

    // Trade Levels: Entry (Orange #FF8C00), Stop Loss (Red #F6465D), TPs (Blue #2962FF)
    const levels = [
      { label: `ENTRY: ${signal.suggestedEntryPrice.toFixed(2)}`, price: signal.suggestedEntryPrice, color: '#FF8C00' },
      { label: `SL: ${signal.stopLossPrice.toFixed(2)}`, price: signal.stopLossPrice, color: '#F6465D' },
      { label: `TP1: ${signal.tp1Price.toFixed(2)}`, price: signal.tp1Price, color: '#2962FF' },
      { label: `TP2: ${signal.tp2Price.toFixed(2)}`, price: signal.tp2Price, color: '#2962FF' }
    ];

    levels.forEach((lvl) => {
      const y = priceToY(lvl.price);
      svg += `<line x1="${padding.left}" y1="${y}" x2="${width - padding.right}" y2="${y}" stroke="${lvl.color}" stroke-width="1.5" stroke-dasharray="3,3" />`;
      svg += `<text x="${width - padding.right + 6}" y="${y + 4}" fill="${lvl.color}" font-size="10" font-weight="600">${lvl.label}</text>`;
    });

    // Title / Header banner
    svg += `<text x="${padding.left}" y="24" fill="#EAECEF" font-size="14" font-weight="700">${symbol} — ${timeframe.toUpperCase()} | ${signal.direction} (${signal.strategyId.replace(/_/g, ' ')})</text>`;

    svg += `</svg>`;
    return svg;
  }

  public renderBuffer(options: ChartRenderOptions): Buffer {
    const svgStr = this.renderSvg(options);
    return Buffer.from(svgStr, 'utf-8');
  }
}
