import { Candle } from '@crypto-signal/market-data';
import { StrategySignal } from '@crypto-signal/strategies';

export interface ChartRenderOptions {
  width: number;
  height: number;
  symbol: string;
  timeframe: string;
  candles: Candle[];
  signal: StrategySignal;
}
