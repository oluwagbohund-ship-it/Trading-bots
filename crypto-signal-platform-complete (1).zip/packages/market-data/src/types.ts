export interface Candle {
  openTime: number;
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number;
  closeTime: number;
  isClosed: boolean;
}

export type Timeframe = '1m' | '5m' | '1h' | '4h' | '1d' | '1w' | '1M';
