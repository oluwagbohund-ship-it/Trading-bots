import WebSocket from 'ws';
import { Candle, Timeframe } from './types.js';

export class BinanceWebSocketClient {
  private ws: WebSocket | null = null;
  private reconnectAttempts = 0;
  private maxReconnectAttempts = 10;
  private baseBackoffMs = 1000;
  private isRunning = false;
  private lastCandleTime = 0;

  constructor(
    private symbol: string,
    private interval: Timeframe,
    private onCandleUpdate: (candle: Candle) => void
  ) {}

  public connect() {
    this.isRunning = true;
    const streamName = `${this.symbol.toLowerCase()}@kline_${this.interval}`;
    const url = `wss://data-stream.binance.vision/ws/${streamName}`;

    console.log(`Connecting to Binance WS: ${url}`);
    this.ws = new WebSocket(url);

    this.ws.on('open', () => {
      console.log(`Binance WS connected for ${this.symbol} (${this.interval})`);
      this.reconnectAttempts = 0;
    });

    this.ws.on('message', (data: WebSocket.Data) => {
      try {
        const message = JSON.parse(data.toString());
        if (message.k) {
          const k = message.k;
          const candle: Candle = {
            openTime: k.t,
            open: parseFloat(k.o),
            high: parseFloat(k.h),
            low: parseFloat(k.l),
            close: parseFloat(k.c),
            volume: parseFloat(k.v),
            closeTime: k.T,
            isClosed: k.x // k.x is true when the candle is closed
          };

          // Duplicate candle protection / timestamp validation
          if (candle.openTime === this.lastCandleTime && !candle.isClosed) {
            // Update within same open bar
          }
          this.lastCandleTime = candle.openTime;

          this.onCandleUpdate(candle);
        }
      } catch (err) {
        console.error('Error parsing WS message:', err);
      }
    });

    this.ws.on('close', () => {
      console.warn('Binance WS disconnected.');
      this.handleReconnect();
    });

    this.ws.on('error', (err) => {
      console.error('Binance WS error:', err);
      this.ws?.terminate();
    });
  }

  private handleReconnect() {
    if (!this.isRunning) return;
    if (this.reconnectAttempts >= this.maxReconnectAttempts) {
      console.error('Max reconnection attempts reached. Polling fallback recommended.');
      return;
    }

    const backoff = Math.min(this.baseBackoffMs * Math.pow(2, this.reconnectAttempts), 30000);
    this.reconnectAttempts++;
    console.log(`Reconnecting in ${backoff}ms (attempt ${this.reconnectAttempts})...`);

    setTimeout(() => {
      if (this.isRunning) this.connect();
    }, backoff);
  }

  public disconnect() {
    this.isRunning = false;
    this.ws?.terminate();
    this.ws = null;
  }
}
