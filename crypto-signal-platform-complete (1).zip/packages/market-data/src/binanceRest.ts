import fetch from 'node-fetch';
import { Candle, Timeframe } from './types.js';

const PRIMARY_REST = 'https://data-api.binance.vision';
const FALLBACK_REST = 'https://api.binance.com';

export class BinanceRest {
  private async fetchWithFallback(endpoint: string): Promise<any> {
    const urls = [`${PRIMARY_REST}${endpoint}`, `${FALLBACK_REST}${endpoint}`];
    for (const url of urls) {
      try {
        const response = await fetch(url);
        if (!response.ok) throw new Error(`HTTP error! status: ${response.status}`);
        return await response.json();
      } catch (error) {
        console.warn(`Failed fetching from ${url}, trying fallback...`, error);
      }
    }
    throw new Error('All Binance REST endpoints failed.');
  }

  async getHistoricalCandles(symbol: string, interval: Timeframe, limit = 500): Promise<Candle[]> {
    const endpoint = `/api/v3/klines?symbol=${symbol.toUpperCase()}&interval=${interval}&limit=${limit}`;
    const data = await this.fetchWithFallback(endpoint);
    
    return data.map((k: any[]) => ({
      openTime: k[0],
      open: parseFloat(k[1]),
      high: parseFloat(k[2]),
      low: parseFloat(k[3]),
      close: parseFloat(k[4]),
      volume: parseFloat(k[5]),
      closeTime: k[6],
      isClosed: true // Historical candles are closed
    }));
  }
}
