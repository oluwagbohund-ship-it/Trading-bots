# Trendline Detection Engine Methodology

## Verified Tori Trades Principles Implemented
1. **Swing-Point Anchors**: Trendlines connect confirmed swing lows (ascending) or swing highs (descending) rather than arbitrary candle closes or forced linear regressions.
2. **Ray Projection**: Valid trendlines extend forward in time as rays into lower timeframes (e.g., 4H trendlines projected onto 5M execution charts).
3. **No Body-Cut Rule**: A candidate line between two anchor swings is invalidated if closed candle bodies cut through the line between the anchors.
4. **Touch & Break Confirmation**:
   - **Bounce / Touch**: Price tests the projected trendline within a configurable tolerance without a confirmed candle close beyond the line.
   - **Breakout**: A closed candle finishes decisively past the trendline beyond the violation threshold.

## Documented Engineering Assumptions (Configurable Parameters)
Because visual discretionary charting does not specify exact numerical tolerances, the following parameters are explicitly isolated in `TrendlineConfig` for empirical backtest validation:
- `touchTolerancePercent` (default `0.25%`): Defines proximity required for a wick test to qualify as a touch.
- `maxViolationPercent` (default `0.10%`): Minimum close distance past the ray required to filter out minor wick noise before flagging a structural break.
- `minTouches` (default `3`): Requires 2 defining anchor swings plus at least 1 subsequent confirmed touch.
