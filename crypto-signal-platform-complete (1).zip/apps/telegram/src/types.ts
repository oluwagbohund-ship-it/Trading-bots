import { StrategySignal } from '@crypto-signal/strategies';

export interface TelegramUserState {
  chatId: number;
  accountId: string;
  accountBalance: number; // Default $1,000 simulated balance
  isPaused: boolean;
  activeSignals: Map<string, ActiveSignalTracking>;
}

export interface ActiveSignalTracking {
  signalId: string;
  symbol: string;
  direction: 'BUY' | 'SELL';
  entryPrice: number;
  stopLossPrice: number;
  tp1Price: number;
  tp2Price: number;
  tp3Price: number;
  currentStopLoss: number;
  tp1Reached: boolean;
  tp2Reached: boolean;
  tp3Reached: boolean;
  beMoved: boolean;
  status: 'ACTIVE' | 'TP1_HIT' | 'TP2_HIT' | 'TP3_HIT' | 'STOP_LOSS' | 'CLOSED';
}
