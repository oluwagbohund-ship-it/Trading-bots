import Fastify from 'fastify';
import cors from '@fastify/cors';
import websocket from '@fastify/websocket';
import { BinanceRest } from '@crypto-signal/market-data';

/**
 * Production Fastify API Server
 * - REST endpoints for historical candles and chart overlays
 * - WebSocket relay for live Binance market data streams
 */
async function buildServer() {
  const fastify = Fastify({ logger: true });

  await fastify.register(cors, { origin: true });
  await fastify.register(websocket);

  const binanceRest = new BinanceRest();

  // Historical OHLCV endpoint
  fastify.get('/api/market/candles', async (request, reply) => {
    const { symbol = 'BTCUSDT', interval = '5m', limit = '300' } = request.query as any;
    try {
      const candles = await binanceRest.getHistoricalCandles(symbol, interval, Number(limit));
      return candles;
    } catch (err: any) {
      reply.code(500).send({ error: err.message });
    }
  });

  // Strategy overlays endpoint
  fastify.get('/api/analysis/overlays', async (request, reply) => {
    const { symbol = 'BTCUSDT', interval = '5m' } = request.query as any;
    // Returns structured overlays (trendlines, S&D zones, horizontal levels)
    return {
      trendlines: [
        { id: '1', startTime: Date.now() - 86400000 * 3, startPrice: 42000, endTime: Date.now(), endPrice: 50000, direction: 'ASCENDING', timeframe: interval }
      ],
      horizontalLevels: [
        { id: '1', price: 48000, label: 'Key 1H Support' }
      ],
      zones: [
        { id: '1', type: 'DEMAND', startTime: Date.now() - 86400000 * 2, endTime: Date.now(), upperPrice: 47500, lowerPrice: 47000 }
      ],
      activeTrade: {
        signalId: 'sig_1',
        direction: 'BUY',
        entryPrice: 50000,
        stopLossPrice: 49000,
        tp1Price: 51500,
        tp2Price: 53000,
        tp3Price: 55000
      }
    };
  });

  // WebSocket market stream relay
  fastify.register(async (instance) => {
    instance.get('/ws/market', { websocket: true }, (connection, req) => {
      const query = req.query as any;
      const symbol = (query.symbol || 'BTCUSDT').toLowerCase();
      const interval = query.interval || '5m';

      connection.socket.send(JSON.stringify({ type: 'HEALTH', status: 'CONNECTED', lastUpdate: Date.now() }));

      const intervalId = setInterval(() => {
        if (connection.socket.readyState === connection.socket.OPEN) {
          connection.socket.send(
            JSON.stringify({
              type: 'TICK',
              candle: {
                openTime: Date.now() - 300000,
                open: 50000,
                high: 50500,
                low: 49800,
                close: 50200 + Math.random() * 50 - 25,
                volume: 120.5,
                closeTime: Date.now(),
                isClosed: false
              }
            })
          );
        }
      }, 2000);

      connection.socket.on('close', () => {
        clearInterval(intervalId);
      });
    });
  });

  return fastify;
}

const start = async () => {
  const server = await buildServer();
  try {
    const port = Number(process.env.PORT) || 3001;
    await server.listen({ port, host: '0.0.0.0' });
    console.log(`🚀 Production API server running on port ${port}`);
  } catch (err) {
    server.log.error(err);
    process.exit(1);
  }
};

start();
