export type TimeframeOption = '1m' | '5m' | '1h' | '4h' | '1d' | '1w' | '1M';

export type ConnectionHealth = 'CONNECTED' | 'RECONNECTING' | 'POLLING_FALLBACK' | 'DISCONNECTED';

export interface ChartCandle {
  timestamp: number;
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number;
}

export interface ChartTrendlineOverlay {
  id: string;
  startTime: number;
  startPrice: number;
  endTime: number;
  endPrice: number;
  direction: 'ASCENDING' | 'DESCENDING';
  timeframe: string;
}

export interface ChartHorizontalLevelOverlay {
  id: string;
  price: number;
  label: string;
}

export interface ChartZoneOverlay {
  id: string;
  type: 'SUPPLY' | 'DEMAND';
  startTime: number;
  endTime: number;
  upperPrice: number;
  lowerPrice: number;
}

export interface ChartTradeOverlay {
  signalId: string;
  direction: 'BUY' | 'SELL';
  entryPrice: number;
  stopLossPrice: number;
  tp1Price: number;
  tp2Price: number;
  tp3Price: number;
}

export interface ChartAnalysisOverlays {
  trendlines: ChartTrendlineOverlay[];
  horizontalLevels: ChartHorizontalLevelOverlay[];
  zones: ChartZoneOverlay[];
  activeTrade?: ChartTradeOverlay;
}
