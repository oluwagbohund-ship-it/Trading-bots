import React, { useEffect, useMemo, useState } from 'react';
import {
  ChartAnalysisOverlays,
  ChartCandle,
  ConnectionHealth,
  TimeframeOption
} from './types/chart';
import { BackendMarketClient } from './services/marketStreamClient';
import { TopToolbar } from './components/TopToolbar';
import { BinanceChart } from './components/BinanceChart';

const WATCHLIST = ['BTCUSDT', 'ETHUSDT', 'SOLUSDT', 'BNBUSDT', 'XRPUSDT'];

export const App: React.FC = () => {
  const [symbol, setSymbol] = useState<string>('BTCUSDT');
  const [timeframe, setTimeframe] = useState<TimeframeOption>('5m');
  const [candles, setCandles] = useState<ChartCandle[]>([]);
  const [latestCandle, setLatestCandle] = useState<ChartCandle | null>(null);
  const [health, setHealth] = useState<ConnectionHealth>('DISCONNECTED');
  const [lastUpdateTs, setLastUpdateTs] = useState<number | null>(null);
  const [overlays, setOverlays] = useState<ChartAnalysisOverlays>({
    trendlines: [],
    horizontalLevels: [],
    zones: []
  });

  const marketClient = useMemo(() => new BackendMarketClient(), []);

  useEffect(() => {
    let active = true;

    const loadData = async () => {
      try {
        const hist = await marketClient.fetchHistoricalCandles(symbol, timeframe, 300);
        if (!active) return;
        setCandles(hist);
        if (hist.length > 0) {
          setLatestCandle(hist[hist.length - 1]);
        }

        // Fetch active strategy overlays for the symbol/timeframe
        const overlayRes = await fetch(`/api/analysis/overlays?symbol=${symbol}&interval=${timeframe}`);
        if (overlayRes.ok && active) {
          const data = await overlayRes.json();
          setOverlays(data);
        }
      } catch (err) {
        console.error('Error loading market data:', err);
        if (active) setHealth('DISCONNECTED');
      }
    };

    loadData();

    const unsubscribe = marketClient.subscribeLiveCandles(
      symbol,
      timeframe,
      (candle) => {
        if (!active) return;
        setLatestCandle(candle);
      },
      (newHealth, ts) => {
        if (!active) return;
        setHealth(newHealth);
        setLastUpdateTs(ts);
      }
    );

    return () => {
      active = false;
      unsubscribe();
    };
  }, [symbol, timeframe, marketClient]);

  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100vh', backgroundColor: '#0B0E11' }}>
      <TopToolbar
        symbol={symbol}
        symbols={WATCHLIST}
        timeframe={timeframe}
        lastPrice={latestCandle?.close ?? null}
        health={health}
        lastUpdateTs={lastUpdateTs}
        onSymbolChange={setSymbol}
        onTimeframeChange={setTimeframe}
      />

      <main style={{ flex: 1, position: 'relative', overflow: 'hidden' }}>
        <BinanceChart candles={candles} latestCandle={latestCandle} overlays={overlays} />

        {/* Small Price-Axis Legend for Active Trade Levels */}
        {overlays.activeTrade && (
          <aside
            style={{
              position: 'absolute',
              top: '12px',
              left: '12px',
              backgroundColor: 'rgba(22, 26, 30, 0.92)',
              border: '1px solid #2B3139',
              borderRadius: '6px',
              padding: '8px 12px',
              fontSize: '12px',
              display: 'flex',
              flexDirection: 'column',
              gap: '4px',
              pointerEvents: 'none'
            }}
          >
            <div style={{ fontWeight: 700, color: '#EAECEF' }}>
              {symbol} — {overlays.activeTrade.direction} (PAPER ACTIVE)
            </div>
            <div style={{ color: '#FF8C00' }}>Entry: {overlays.activeTrade.entryPrice.toFixed(2)}</div>
            <div style={{ color: '#F6465D' }}>Stop Loss: {overlays.activeTrade.stopLossPrice.toFixed(2)} (-1R)</div>
            <div style={{ color: '#2962FF' }}>TP1: {overlays.activeTrade.tp1Price.toFixed(2)} (1.5R)</div>
            <div style={{ color: '#2962FF' }}>TP2: {overlays.activeTrade.tp2Price.toFixed(2)} (3.0R)</div>
            <div style={{ color: '#2962FF' }}>TP3: {overlays.activeTrade.tp3Price.toFixed(2)} (Runner)</div>
          </aside>
        )}
      </main>
    </div>
  );
};
