import React from 'react';
import { ConnectionHealth, TimeframeOption } from '../types/chart';

interface TopToolbarProps {
  symbol: string;
  symbols: string[];
  timeframe: TimeframeOption;
  lastPrice: number | null;
  health: ConnectionHealth;
  lastUpdateTs: number | null;
  onSymbolChange: (symbol: string) => void;
  onTimeframeChange: (tf: TimeframeOption) => void;
}

const TIMEFRAMES: TimeframeOption[] = ['1m', '5m', '1h', '4h', '1d', '1w', '1M'];

export const TopToolbar: React.FC<TopToolbarProps> = ({
  symbol,
  symbols,
  timeframe,
  lastPrice,
  health,
  lastUpdateTs,
  onSymbolChange,
  onTimeframeChange
}) => {
  const badgeColor =
    health === 'CONNECTED'
      ? '#0ECB81'
      : health === 'RECONNECTING' || health === 'POLLING_FALLBACK'
      ? '#FCD535'
      : '#F6465D';

  return (
    <header
      style={{
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        padding: '10px 16px',
        backgroundColor: '#161A1E',
        borderBottom: '1px solid #2B3139',
        gap: '16px',
        flexWrap: 'wrap'
      }}
    >
      {/* Symbol & Live Price */}
      <div style={{ display: 'flex', alignItems: 'center', gap: '16px' }}>
        <select
          value={symbol}
          onChange={(e) => onSymbolChange(e.target.value)}
          style={{
            backgroundColor: '#2B3139',
            color: '#EAECEF',
            border: '1px solid #474D57',
            borderRadius: '4px',
            padding: '6px 10px',
            fontWeight: 600,
            fontSize: '14px',
            cursor: 'pointer'
          }}
        >
          {symbols.map((s) => (
            <option key={s} value={s}>
              {s}
            </option>
          ))}
        </select>

        {lastPrice !== null && (
          <span style={{ fontSize: '16px', fontWeight: 700, color: '#0ECB81', fontVariantNumeric: 'tabular-nums' }}>
            {lastPrice.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 6 })}
          </span>
        )}

        {/* Timeframe Ladder Selector */}
        <div style={{ display: 'flex', gap: '4px', backgroundColor: '#0B0E11', padding: '3px', borderRadius: '4px' }}>
          {TIMEFRAMES.map((tf) => {
            const active = tf === timeframe;
            return (
              <button
                key={tf}
                onClick={() => onTimeframeChange(tf)}
                style={{
                  backgroundColor: active ? '#2B3139' : 'transparent',
                  color: active ? '#FCD535' : '#848E9C',
                  border: 'none',
                  borderRadius: '3px',
                  padding: '4px 8px',
                  fontSize: '12px',
                  fontWeight: active ? 600 : 400,
                  cursor: 'pointer'
                }}
              >
                {tf.toUpperCase()}
              </button>
            );
          })}
        </div>
      </div>

      {/* Connection Health Badge */}
      <div style={{ display: 'flex', alignItems: 'center', gap: '8px', fontSize: '12px', color: '#848E9C' }}>
        <span
          style={{
            display: 'inline-flex',
            alignItems: 'center',
            gap: '6px',
            padding: '4px 10px',
            borderRadius: '12px',
            backgroundColor: '#0B0E11',
            border: `1px solid ${badgeColor}`,
            color: badgeColor,
            fontWeight: 600
          }}
        >
          <span
            style={{
              width: '7px',
              height: '7px',
              borderRadius: '50%',
              backgroundColor: badgeColor
            }}
          />
          {health}
        </span>
        {lastUpdateTs && (
          <span>Updated {new Date(lastUpdateTs).toLocaleTimeString()}</span>
        )}
      </div>
    </header>
  );
};
