import React from 'react';

export interface StrategyPerformanceMetrics {
  strategyName: string;
  grade: 'A' | 'B' | 'C' | 'D';
  winRate: number;
  profitFactor: number;
  netProfitUsd: number;
  maxDrawdown: number;
  totalTrades: number;
}

interface PerformanceDashboardProps {
  metrics: StrategyPerformanceMetrics[];
}

export const PerformanceDashboard: React.FC<PerformanceDashboardProps> = ({ metrics }) => {
  const getGradeColor = (grade: string) => {
    switch (grade) {
      case 'A': return '#0ECB81';
      case 'B': return '#2962FF';
      case 'C': return '#FCD535';
      default: return '#F6465D';
    }
  };

  return (
    <div style={{ padding: '24px', backgroundColor: '#0B0E11', color: '#EAECEF', height: '100%', overflowY: 'auto' }}>
      <h2 style={{ fontSize: '20px', fontWeight: 700, marginBottom: '16px' }}>Strategy Validation & Performance Dashboard</h2>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))', gap: '16px' }}>
        {metrics.map((m) => {
          const color = getGradeColor(m.grade);
          return (
            <div
              key={m.strategyName}
              style={{
                backgroundColor: '#161A1E',
                border: '1px solid #2B3139',
                borderRadius: '8px',
                padding: '20px',
                display: 'flex',
                flexDirection: 'column',
                gap: '12px'
              }}
            >
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <span style={{ fontSize: '16px', fontWeight: 600 }}>{m.strategyName}</span>
                <span
                  style={{
                    backgroundColor: 'rgba(255,255,255,0.05)',
                    border: `1px solid ${color}`,
                    color,
                    padding: '4px 10px',
                    borderRadius: '6px',
                    fontWeight: 700,
                    fontSize: '14px'
                  }}
                >
                  Grade {m.grade}
                </span>
              </div>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '8px', fontSize: '13px', color: '#848E9C' }}>
                <div>Win Rate: <span style={{ color: '#EAECEF', fontWeight: 600 }}>{m.winRate.toFixed(1)}%</span></div>
                <div>Profit Factor: <span style={{ color: '#EAECEF', fontWeight: 600 }}>{m.profitFactor.toFixed(2)}</span></div>
                <div>Net PnL: <span style={{ color: m.netProfitUsd >= 0 ? '#0ECB81' : '#F6465D', fontWeight: 600 }}>${m.netProfitUsd.toLocaleString()}</span></div>
                <div>Max Drawdown: <span style={{ color: '#F6465D', fontWeight: 600 }}>{m.maxDrawdown.toFixed(1)}%</span></div>
              </div>
              <div style={{ fontSize: '11px', color: '#848E9C', borderTop: '1px solid #2B3139', paddingTop: '8px' }}>
                Total Evaluated Trades: {m.totalTrades} (Walk-Forward 70/30 Split)
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
