import React, { useEffect, useRef } from 'react';
import { init, dispose, Chart } from 'klinecharts';
import { ChartCandle, ChartAnalysisOverlays } from '../types/chart';

interface BinanceChartProps {
  candles: ChartCandle[];
  latestCandle: ChartCandle | null;
  overlays: ChartAnalysisOverlays;
}

export const BinanceChart: React.FC<BinanceChartProps> = ({ candles, latestCandle, overlays }) => {
  const containerRef = useRef<HTMLDivElement | null>(null);
  const chartRef = useRef<Chart | null>(null);

  useEffect(() => {
    if (!containerRef.current) return;

    const chart = init(containerRef.current, {
      styles: {
        grid: {
          show: true,
          horizontal: { show: true, size: 1, color: '#1E2329', style: 'solid' },
          vertical: { show: true, size: 1, color: '#1E2329', style: 'solid' }
        },
        candle: {
          bar: {
            upColor: '#0ECB81',
            downColor: '#F6465D',
            noChangeColor: '#848E9C',
            upBorderColor: '#0ECB81',
            downBorderColor: '#F6465D',
            noChangeBorderColor: '#848E9C',
            upWickColor: '#0ECB81',
            downWickColor: '#F6465D',
            noChangeWickColor: '#848E9C'
          },
          priceMark: {
            show: true,
            last: {
              show: true,
              upColor: '#0ECB81',
              downColor: '#F6465D',
              noChangeColor: '#848E9C',
              line: { show: true, style: 'dashed', size: 1 },
              text: { show: true, size: 11, color: '#FFFFFF' }
            }
          }
        },
        xAxis: {
          axisLine: { color: '#2B3139' },
          tickLine: { color: '#2B3139' },
          tickText: { color: '#848E9C', size: 11 }
        },
        yAxis: {
          axisLine: { color: '#2B3139' },
          tickLine: { color: '#2B3139' },
          tickText: { color: '#848E9C', size: 11 }
        },
        crosshair: {
          show: true,
          horizontal: {
            line: { color: '#848E9C', style: 'dashed', size: 1 },
            text: { backgroundColor: '#2B3139', color: '#EAECEF', size: 11 }
          },
          vertical: {
            line: { color: '#848E9C', style: 'dashed', size: 1 },
            text: { backgroundColor: '#2B3139', color: '#EAECEF', size: 11 }
          }
        }
      }
    });

    if (chart) {
      chart.createIndicator('VOL', false, { id: 'volume_pane', height: 90 });
      chartRef.current = chart;
    }

    const handleResize = () => {
      chartRef.current?.resize();
    };
    window.addEventListener('resize', handleResize);

    return () => {
      window.removeEventListener('resize', handleResize);
      if (containerRef.current) {
        dispose(containerRef.current);
      }
      chartRef.current = null;
    };
  }, []);

  useEffect(() => {
    if (!chartRef.current || candles.length === 0) return;
    chartRef.current.parseDataList(candles);
  }, [candles]);

  useEffect(() => {
    if (!chartRef.current || !latestCandle) return;
    chartRef.current.updateData(latestCandle);
  }, [latestCandle]);

  useEffect(() => {
    const chart = chartRef.current;
    if (!chart) return;

    const cappedTrendlines = overlays.trendlines.slice(0, 4);
    cappedTrendlines.forEach((tl) => {
      chart.createOverlay({
        name: 'rayLine',
        id: `tl_${tl.id}`,
        lock: true,
        points: [
          { timestamp: tl.startTime, value: tl.startPrice },
          { timestamp: tl.endTime, value: tl.endPrice }
        ],
        styles: {
          line: {
            color: tl.direction === 'ASCENDING' ? '#0ECB81' : '#F6465D',
            size: 1,
            style: 'solid'
          }
        }
      });
    });

    const cappedLevels = overlays.horizontalLevels.slice(0, 3);
    cappedLevels.forEach((lvl) => {
      chart.createOverlay({
        name: 'horizontalStraightLine',
        id: `lvl_${lvl.id}`,
        lock: true,
        points: [{ value: lvl.price }],
        styles: {
          line: {
            color: '#FCD535',
            size: 1,
            style: 'dashed'
          }
        }
      });
    });

    const cappedZones = overlays.zones.slice(0, 2);
    cappedZones.forEach((zone) => {
      const fillColor = zone.type === 'DEMAND' ? 'rgba(14, 203, 129, 0.14)' : 'rgba(246, 70, 93, 0.14)';
      const borderColor = zone.type === 'DEMAND' ? 'rgba(14, 203, 129, 0.45)' : 'rgba(246, 70, 93, 0.45)';
      chart.createOverlay({
        name: 'rect',
        id: `zone_${zone.id}`,
        lock: true,
        points: [
          { timestamp: zone.startTime, value: zone.upperPrice },
          { timestamp: zone.endTime, value: zone.lowerPrice }
        ],
        styles: {
          polygon: {
            style: 'stroke_fill',
            color: fillColor,
            borderColor,
            borderSize: 1
          }
        }
      });
    });

    if (overlays.activeTrade) {
      const t = overlays.activeTrade;
      const lines = [
        { id: 'entry', price: t.entryPrice, color: '#FF8C00', style: 'solid' },
        { id: 'sl', price: t.stopLossPrice, color: '#F6465D', style: 'dashed' },
        { id: 'tp1', price: t.tp1Price, color: '#2962FF', style: 'dashed' },
        { id: 'tp2', price: t.tp2Price, color: '#2962FF', style: 'dashed' },
        { id: 'tp3', price: t.tp3Price, color: '#2962FF', style: 'dotted' }
      ];

      lines.forEach((item) => {
        chart.createOverlay({
          name: 'horizontalStraightLine',
          id: `trade_${t.signalId}_${item.id}`,
          lock: true,
          points: [{ value: item.price }],
          styles: {
            line: {
              color: item.color,
              size: 1.5,
              style: item.style as any
            }
          }
        });
      });
    }
  }, [overlays]);

  return (
    <div
      ref={containerRef}
      style={{
        width: '100%',
        height: '100%',
        backgroundColor: '#0B0E11'
      }}
    />
  );
};
