import { ChartCandle, ConnectionHealth, TimeframeOption } from '../types/chart';

/**
 * Frontend Market Data Client
 * Connects exclusively to the platform's backend API/WebSocket relay
 * so all Binance requests originate from the backend.
 */
export class BackendMarketClient {
  private ws: WebSocket | null = null;
  private reconnectTimer: ReturnType<typeof setTimeout> | null = null;
  private reconnectAttempts = 0;
  private isDisposed = false;

  public async fetchHistoricalCandles(
    symbol: string,
    timeframe: TimeframeOption,
    limit = 300
  ): Promise<ChartCandle[]> {
    const res = await fetch(`/api/market/candles?symbol=${encodeURIComponent(symbol)}&interval=${timeframe}&limit=${limit}`);
    if (!res.ok) {
      throw new Error(`Failed to fetch historical candles: ${res.status}`);
    }
    const raw = await res.json();
    return raw.map((c: any) => ({
      timestamp: c.openTime,
      open: Number(c.open),
      high: Number(c.high),
      low: Number(c.low),
      close: Number(c.close),
      volume: Number(c.volume)
    }));
  }

  public subscribeLiveCandles(
    symbol: string,
    timeframe: TimeframeOption,
    onCandle: (candle: ChartCandle, isClosed: boolean) => void,
    onHealthChange: (health: ConnectionHealth, lastUpdateTs: number) => void
  ): () => void {
    this.isDisposed = false;

    const connect = () => {
      if (this.isDisposed) return;
      const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
      const wsUrl = `${protocol}//${window.location.host}/ws/market?symbol=${encodeURIComponent(symbol)}&interval=${timeframe}`;

      this.ws = new WebSocket(wsUrl);

      this.ws.onopen = () => {
        this.reconnectAttempts = 0;
        onHealthChange('CONNECTED', Date.now());
      };

      this.ws.onmessage = (event) => {
        try {
          const payload = JSON.parse(event.data);
          if (payload.type === 'HEALTH') {
            onHealthChange(payload.status, payload.lastUpdate || Date.now());
            return;
          }
          if (payload.candle) {
            const k = payload.candle;
            onCandle(
              {
                timestamp: k.openTime,
                open: Number(k.open),
                high: Number(k.high),
                low: Number(k.low),
                close: Number(k.close),
                volume: Number(k.volume)
              },
              Boolean(k.isClosed)
            );
            onHealthChange('CONNECTED', Date.now());
          }
        } catch (err) {
          console.error('Stream parse error:', err);
        }
      };

      this.ws.onclose = () => {
        if (this.isDisposed) return;
        onHealthChange('RECONNECTING', Date.now());
        const delay = Math.min(1000 * Math.pow(2, this.reconnectAttempts), 15000);
        this.reconnectAttempts++;
        this.reconnectTimer = setTimeout(connect, delay);
      };

      this.ws.onerror = () => {
        this.ws?.close();
      };
    };

    connect();

    return () => {
      this.isDisposed = true;
      if (this.reconnectTimer) clearTimeout(this.reconnectTimer);
      this.ws?.close();
      this.ws = null;
    };
  }
}
