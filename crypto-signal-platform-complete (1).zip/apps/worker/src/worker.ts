import { BinanceRest } from '@crypto-signal/market-data';
import { TopDownTrendlineStrategy, MultiTimeframeSnapshot } from '@crypto-signal/strategies';
import { CryptoSignalTelegramBot } from '@crypto-signal/telegram';
import { ServerSideChartRenderer } from '@crypto-signal/chart-renderer';

const WATCHLIST = ['BTCUSDT', 'ETHUSDT', 'SOLUSDT', 'BNBUSDT'];
const TOKEN = process.env.TELEGRAM_BOT_TOKEN || 'DUMMY_TOKEN';

/**
 * 24/7 Autonomous Background Signal-Scanning Worker
 * - Runs independently without Google Colab or Gemini dependencies
 * - Continuously polls Binance public market data across timeframes
 * - Evaluates strategies, runs risk checks, generates chart images, and publishes to Telegram
 */
async function runSignalWorker() {
  console.log('👷 Starting 24/7 Signal-Scanning Worker...');
  const binanceRest = new BinanceRest();
  const strategy = new TopDownTrendlineStrategy();
  const bot = new CryptoSignalTelegramBot(TOKEN);
  const chartRenderer = new ServerSideChartRenderer();

  setInterval(async () => {
    for (const symbol of WATCHLIST) {
      try {
        const [candles5m, candles1h, candles4h, candles1d] = await Promise.all([
          binanceRest.getHistoricalCandles(symbol, '5m', 200),
          binanceRest.getHistoricalCandles(symbol, '1h', 100),
          binanceRest.getHistoricalCandles(symbol, '4h', 100),
          binanceRest.getHistoricalCandles(symbol, '1d', 50)
        ]);

        const snapshot: MultiTimeframeSnapshot = {
          symbol,
          timestamp: Date.now(),
          candles: {
            '1m': [],
            '5m': candles5m,
            '1h': candles1h,
            '4h': candles4h,
            '1d': candles1d,
            '1w': [],
            '1M': []
          }
        };

        const signal = strategy.evaluate(snapshot);
        if (signal && signal.qualityScore >= 65) {
          console.log(`🎯 Signal generated for ${symbol}: ${signal.direction} (${signal.strategyId})`);
          const chartBuffer = chartRenderer.renderBuffer({
            width: 800,
            height: 450,
            symbol,
            timeframe: '5m',
            candles: candles5m,
            signal
          });

          // Broadcast to configured test channel / chat ID
          const testChatId = Number(process.env.TELEGRAM_CHAT_ID) || 123456789;
          await bot.publishSignal(testChatId, signal, chartBuffer);
        }
      } catch (err) {
        console.error(`Error scanning ${symbol}:`, err);
      }
    }
  }, 60000); // Scan every 60 seconds
}

runSignalWorker();
