# Crypto Signal Platform

Modular cryptocurrency market analysis, charting, strategy testing and Telegram signal platform.
