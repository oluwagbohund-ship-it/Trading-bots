import { describe, it, expect } from 'vitest';
import { Candle } from '@crypto-signal/market-data';
import { HistoricalReplayEngine } from '../packages/backtesting/src/replay/replayEngine.js';

describe('HistoricalReplayEngine', () => {
  it('hides future candles, enforces overlay limits, executes manual 1% risk paper trades, and logs journal entries', () => {
    const baseTime = 1700000000000;
    const step = 300000; // 5m

    const candles: Candle[] = Array.from({ length: 20 }, (_, i) => ({
      openTime: baseTime + i * step,
      open: 100 + i,
      high: 102 + i,
      low: 99 + i,
      close: 101 + i,
      volume: 500,
      closeTime: baseTime + (i + 1) * step - 1,
      isClosed: true
    }));

    // Start at index 5 (timestamp = baseTime + 5 * step)
    const replay = new HistoricalReplayEngine('BTCUSDT', '5m', candles, baseTime + 5 * step, 1000);
    const initialSnap = replay.getSnapshot();

    // Must expose only bars 0..5 (6 bars) and strictly hide bars 6..19
    expect(initialSnap.visibleCandles.length).toBe(6);
    expect(initialSnap.visibleCandles[5].close).toBe(106);

    // Add 5 trendlines -> should cap at maximum 4 trendlines
    for (let t = 0; t < 5; t++) {
      replay.addTrendline({
        id: `tl_${t}`,
        timeframe: '5m',
        startTime: baseTime,
        startPrice: 100,
        endTime: baseTime + 5 * step,
        endPrice: 105 + t
      });
    }
    expect(replay.getSnapshot().trendlines.length).toBe(4);

    // Open manual paper trade at close = 106, SL = 104 (risk = 2), TP2 = 110 (reward = 4 -> 1:2 R:R)
    const pos = replay.openManualPaperTrade({
      direction: 'BUY',
      stopLossPrice: 104,
      tp1Price: 109,
      tp2Price: 110,
      tp3Price: 114,
      notes: 'Ascending channel bounce'
    });
    expect(pos.riskAmountUsd).toBe(10); // 1% of $1,000
    expect(pos.quantity).toBe(5); // $10 / $2 = 5 units

    // Log journal entry
    replay.addJournalEntry({
      tradeId: pos.id,
      title: '5M Trendline Bounce Entry',
      notes: 'Confirmed higher low bounce with 1:2 R:R',
      tags: ['trendline', 'bounce']
    });
    expect(replay.getSnapshot().journal.length).toBe(1);

    // Step forward until TP2 (110) is hit on bar 8 (high = 110)
    replay.stepForward(); // bar 6 (high 108)
    replay.stepForward(); // bar 7 (high 109)
    replay.stepForward(); // bar 8 (high 110 -> hits TP2)

    const finalSnap = replay.getSnapshot();
    expect(finalSnap.openPositions.length).toBe(0);
    expect(finalSnap.closedPositions.length).toBe(1);
    expect(finalSnap.closedPositions[0].realizedPnlUsd).toBe(20); // 5 units * $4 gain = +$20 (+2R)
    expect(finalSnap.accountBalance).toBe(1020);
  });
});
