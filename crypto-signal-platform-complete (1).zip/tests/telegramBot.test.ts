import { describe, it, expect } from 'vitest';
import { StrategySignal } from '@crypto-signal/strategies';

describe('Telegram Signal Bot', () => {
  it('formats signal notification correctly with 1% risk and trade parameters', () => {
    const signal: StrategySignal = {
      strategyId: 'TOP_DOWN_TRENDLINE',
      symbol: 'BTCUSDT',
      direction: 'BUY',
      executionTimeframe: '5m',
      higherTimeframeBias: 'BULLISH',
      signalCandleTime: 1700000000000,
      suggestedEntryPrice: 50000,
      stopLossPrice: 49000,
      tp1Price: 51500,
      tp2Price: 53000,
      riskRewardRatio: 3.0,
      qualityScore: 82,
      qualityBreakdown: {},
      relevantTrendlines: [],
      relevantZones: [],
      rationale: 'Test notification'
    };

    expect(signal.symbol).toBe('BTCUSDT');
    expect(signal.direction).toBe('BUY');
    expect(signal.riskRewardRatio).toBeGreaterThanOrEqual(2.0);
    expect(signal.qualityScore).toBeGreaterThanOrEqual(65);
  });
});
