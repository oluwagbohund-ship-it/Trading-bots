import { describe, it, expect } from 'vitest';
import { Candle } from '@crypto-signal/market-data';
import { calculateATR } from '../packages/indicators/src/atr.js';
import { SupplyDemandEngine } from '../packages/indicators/src/supplyDemand/engine.js';

describe('SupplyDemandEngine', () => {
  it('identifies a valid Demand zone from 3 small base candles followed by >= 2 ATR displacement', () => {
    const baseTime = 1700000000000;
    const step = 14400000; // 4H

    const candles: Candle[] = [];
    // 15 baseline candles with ~10 range
    for (let i = 0; i < 15; i++) {
      candles.push({
        openTime: baseTime + i * step,
        open: 100,
        high: 105,
        low: 95,
        close: 101,
        volume: 500,
        closeTime: baseTime + (i + 1) * step - 1,
        isClosed: true
      });
    }

    // 3 tight base candles (indices 15, 16, 17)
    for (let i = 15; i <= 17; i++) {
      candles.push({
        openTime: baseTime + i * step,
        open: 100,
        high: 102,
        low: 99,
        close: 100.5,
        volume: 300,
        closeTime: baseTime + (i + 1) * step - 1,
        isClosed: true
      });
    }

    // Displacement candle (index 18): moves +30 (> 2x ATR of ~10)
    candles.push({
      openTime: baseTime + 18 * step,
      open: 100.5,
      high: 132,
      low: 100,
      close: 130.5,
      volume: 2500,
      closeTime: baseTime + 19 * step - 1,
      isClosed: true
    });

    const atr = calculateATR(candles, 14);
    const engine = new SupplyDemandEngine();
    const zones = engine.detectZones(candles, atr, '4h');

    expect(zones.length).toBe(1);
    expect(zones[0].type).toBe('DEMAND');
    expect(zones[0].baseCandleCount).toBe(3);
    expect(zones[0].displacementAtrMultiple).toBeGreaterThanOrEqual(2.0);
    expect(zones[0].isFresh).toBe(true);
  });
});
