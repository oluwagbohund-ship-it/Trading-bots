import { describe, it, expect } from 'vitest';
import { ServerSideChartRenderer } from '../packages/chart-renderer/src/svgRenderer.js';
import { Candle } from '@crypto-signal/market-data';
import { StrategySignal } from '@crypto-signal/strategies';

describe('ServerSideChartRenderer', () => {
  it('renders SVG chart snapshot with guaranteed price consistency for Telegram signals', () => {
    const candles: Candle[] = Array.from({ length: 50 }, (_, i) => ({
      openTime: 1700000000000 + i * 300000,
      open: 100 + i,
      high: 103 + i,
      low: 98 + i,
      close: 101 + i,
      volume: 1000,
      closeTime: 1700000000000 + (i + 1) * 300000 - 1,
      isClosed: true
    }));

    const signal: StrategySignal = {
      strategyId: 'TOP_DOWN_TRENDLINE',
      symbol: 'BTCUSDT',
      direction: 'BUY',
      executionTimeframe: '5m',
      higherTimeframeBias: 'BULLISH',
      signalCandleTime: 1700000000000,
      suggestedEntryPrice: 125,
      stopLossPrice: 120,
      tp1Price: 132.5,
      tp2Price: 140,
      riskRewardRatio: 3.0,
      qualityScore: 85,
      qualityBreakdown: {},
      relevantTrendlines: [],
      relevantZones: [],
      rationale: 'Renderer test'
    };

    const renderer = new ServerSideChartRenderer();
    const buffer = renderer.renderBuffer({
      width: 800,
      height: 450,
      symbol: 'BTCUSDT',
      timeframe: '5m',
      candles,
      signal
    });

    expect(buffer).toBeInstanceOf(Buffer);
    const svgString = buffer.toString('utf-8');
    expect(svgString).toContain('BTCUSDT');
    expect(svgString).toContain('125.00'); // Entry price consistency
    expect(svgString).toContain('120.00'); // Stop loss consistency
  });
});
