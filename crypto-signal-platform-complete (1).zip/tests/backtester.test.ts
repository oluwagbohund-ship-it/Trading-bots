import { describe, it, expect } from 'vitest';
import { Candle, Timeframe } from '@crypto-signal/market-data';
import { TradingStrategy, MultiTimeframeSnapshot, StrategySignal } from '@crypto-signal/strategies';
import { EventDrivenBacktester } from '../packages/backtesting/src/backtester.js';

describe('EventDrivenBacktester', () => {
  it('enforces next-candle-open entry, partial take profits, break-even stop, and zero lookahead', () => {
    const baseTime = 1700000000000;
    const step = 300000; // 5m

    const candles5m: Candle[] = [];
    for (let i = 0; i < 60; i++) {
      let open = 100;
      let high = 101;
      let low = 99;
      let close = 100;

      // Bar 52: Entry executes at open = 100, stop = 98 (risk = 2), TP1 = 103 (1.5R), TP2 = 106 (3R), TP3 = 110 (5R)
      if (i === 52) {
        open = 100;
        high = 103.5; // Hits TP1 (103) and +1R (102 -> moves stop to BE 100)
        low = 99.5;
        close = 103;
      } else if (i === 53) {
        open = 103;
        high = 110.5; // Hits TP2 (106) and TP3 (110)
        low = 102.5;
        close = 110;
      }

      candles5m.push({
        openTime: baseTime + i * step,
        open,
        high,
        low,
        close,
        volume: 1000,
        closeTime: baseTime + (i + 1) * step - 1,
        isClosed: true
      });
    }

    let triggered = false;
    const mockStrategy: TradingStrategy = {
      id: 'TOP_DOWN_TRENDLINE',
      name: 'Deterministic Test Strategy',
      evaluate(snapshot: MultiTimeframeSnapshot): StrategySignal | null {
        // Trigger once on bar 51 so entry occurs at bar 52 open
        if (!triggered && snapshot.candles['5m'].length === 52) {
          triggered = true;
          const last = snapshot.candles['5m'][51];
          return {
            strategyId: 'TOP_DOWN_TRENDLINE',
            symbol: 'BTCUSDT',
            direction: 'BUY',
            executionTimeframe: '5m',
            higherTimeframeBias: 'BULLISH',
            signalCandleTime: last.openTime,
            suggestedEntryPrice: last.close,
            stopLossPrice: 98,
            tp1Price: 103,
            tp2Price: 106,
            riskRewardRatio: 3.0,
            qualityScore: 85,
            qualityBreakdown: {},
            relevantTrendlines: [],
            relevantZones: [],
            rationale: 'Test trigger at bar 51'
          };
        }
        return null;
      }
    };

    const candlesByTf: Record<Timeframe, Candle[]> = {
      '1m': [],
      '5m': candles5m,
      '1h': [],
      '4h': [],
      '1d': [],
      '1w': [],
      '1M': []
    };

    const backtester = new EventDrivenBacktester({ initialBalance: 1000, slippageRate: 0, feeRate: 0 });
    const report = backtester.run(mockStrategy, 'BTCUSDT', candlesByTf);

    expect(report.totalTrades).toBe(1);
    expect(report.winningTrades).toBe(1);
    expect(report.trades[0].entryTime).toBe(candles5m[52].openTime); // Entered on next candle open
    expect(report.trades[0].tp1Hit).toBe(true);
    expect(report.trades[0].tp2Hit).toBe(true);
    expect(report.trades[0].tp3Hit).toBe(true);
    expect(report.netProfitUsd).toBeGreaterThan(0);
    expect(report.finalBalance).toBeGreaterThan(1000);
  });
});
