import { describe, it, expect } from 'vitest';
import { Candle } from '@crypto-signal/market-data';
import { identifySwingPoints } from '../packages/indicators/src/marketStructure.js';
import { TrendlineEngine } from '../packages/indicators/src/trendlines/engine.js';

describe('TrendlineEngine', () => {
  it('detects a valid ascending trendline with 3 touches and detects breakout', () => {
    const baseTime = 1700000000000;
    const step = 3600000; // 1H

    // Construct synthetic candles forming clear higher lows along slope +10 per bar
    const prices = [
      110, 108, 100, 109, 115, // index 2: swing low at 100
      125, 135, 145, 140, 130,
      125, 130, 120, 135, 145, // index 12: swing low at 120 (slope = 20 / 10 bars = +2/bar)
      155, 160, 150, 142, 136, // index 19: line is at 100 + 2*19 = 138 -> low touches ~138, closes above
      148, 155, 150, 140, 130  // index 24: line is at 100 + 2*24 = 148 -> closes at 130 (confirmed break)
    ];

    const candles: Candle[] = prices.map((close, idx) => ({
      openTime: baseTime + idx * step,
      open: close + 1,
      high: close + 3,
      low: idx === 19 ? 138.0 : close - 2,
      close,
      volume: 1000,
      closeTime: baseTime + (idx + 1) * step - 1,
      isClosed: true
    }));

    // Force exact swing lows at index 2 (100) and index 12 (120)
    candles[2].low = 100;
    candles[12].low = 120;

    const { swingHighs, swingLows } = identifySwingPoints(candles, 2, 2);
    const engine = new TrendlineEngine({ minTouches: 3, touchTolerancePercent: 0.005 });

    const lines = engine.detectTrendlines(candles, swingHighs, swingLows, '1h');
    expect(lines.length).toBeGreaterThanOrEqual(1);

    const ascLine = lines[0];
    expect(ascLine.direction).toBe('ASCENDING');
    expect(ascLine.touchCount).toBeGreaterThanOrEqual(3);
    expect(ascLine.isBroken).toBe(true);
    expect(ascLine.brokenAtIndex).toBeDefined();
  });
});
