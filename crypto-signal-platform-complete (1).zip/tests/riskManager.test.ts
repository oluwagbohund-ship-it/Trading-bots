import { describe, it, expect } from 'vitest';
import { RiskManager } from '../packages/risk-engine/src/riskManager.js';
import { AccountState } from '../packages/risk-engine/src/types.js';
import { StrategySignal } from '@crypto-signal/strategies';

describe('RiskManager & Position Sizing', () => {
  it('correctly calculates 1% risk position size for a $1,000 account', () => {
    const account: AccountState = {
      accountId: 'test_user_1',
      balance: 1000,
      riskPercentage: 1.0,
      openPositionsCount: 0,
      maxOpenTrades: 1,
      dailyLossUsd: 0,
      maxDailyLossUsd: 50
    };

    const signal: StrategySignal = {
      strategyId: 'TOP_DOWN_TRENDLINE',
      symbol: 'BTCUSDT',
      direction: 'BUY',
      executionTimeframe: '5m',
      higherTimeframeBias: 'BULLISH',
      signalCandleTime: 1700000000000,
      suggestedEntryPrice: 50000,
      stopLossPrice: 49000, // $1,000 distance (2%)
      tp1Price: 51500,
      tp2Price: 53000,
      riskRewardRatio: 3.0,
      qualityScore: 80,
      qualityBreakdown: {},
      relevantTrendlines: [],
      relevantZones: [],
      rationale: 'Test signal'
    };

    const riskManager = new RiskManager();
    const result = riskManager.evaluateTradeRisk(account, signal);

    expect(result.approved).toBe(true);
    expect(result.riskAmountUsd).toBe(10); // 1% of $1,000 = $10 risk
    expect(result.contractQuantity).toBe(0.01); // $10 risk / $1,000 stop distance = 0.01 BTC
    expect(result.positionSizeUsd).toBe(500); // 0.01 BTC * $50,000 = $500 position size
    expect(result.tp3Price).toBe(55000); // 5R trailing runner
  });

  it('supports small accounts ($10 balance)', () => {
    const account: AccountState = {
      accountId: 'test_user_2',
      balance: 10,
      riskPercentage: 1.0,
      openPositionsCount: 0,
      maxOpenTrades: 1,
      dailyLossUsd: 0,
      maxDailyLossUsd: 5
    };

    const signal: StrategySignal = {
      strategyId: 'TOP_DOWN_TRENDLINE',
      symbol: 'SOLUSDT',
      direction: 'BUY',
      executionTimeframe: '5m',
      higherTimeframeBias: 'BULLISH',
      signalCandleTime: 1700000000000,
      suggestedEntryPrice: 100,
      stopLossPrice: 95, // $5 distance (5%)
      tp1Price: 107.5,
      tp2Price: 115,
      riskRewardRatio: 3.0,
      qualityScore: 75,
      qualityBreakdown: {},
      relevantTrendlines: [],
      relevantZones: [],
      rationale: 'Small account test'
    };

    const riskManager = new RiskManager();
    const result = riskManager.evaluateTradeRisk(account, signal);

    expect(result.approved).toBe(true);
    expect(result.riskAmountUsd).toBe(0.10); // 1% of $10 = $0.10 risk
    expect(result.contractQuantity).toBe(0.02); // $0.10 / $5 = 0.02 units
  });
});
