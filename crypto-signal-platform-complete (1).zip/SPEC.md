# Crypto Signal Bot & Charting Platform Specification

## Objectives
- Binance public market data integration (no private keys, no mock data).
- Top-down multi-timeframe analysis (1M -> 1W -> 1D -> 4H -> 1H -> 5M).
- Four independent trading strategies (Top-Down Trendline, Break & Retest, Liquidity Sweep Reversal, Order Block Retest).
- Automated 24/7 scanning and Telegram signal delivery with annotated chart images.
- Event-driven backtesting, replay mode, professional validation, and paper trading.
- Clean separation between research (Python/Colab) and production (TypeScript/Node.js/React/Fastify).
